import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
import { visualizer } from 'rollup-plugin-visualizer';
import { defineConfig, loadEnv } from 'vite';

import { BREAKPOINTS_PX } from './src/assets/theme/breakpoints';
import { themeBuildPlugin } from './vite-plugin-assets-build';
import { fontsStylesheetPlugin } from './vite-plugin-fonts-stylesheet';

// Inject breakpoint tokens (px) into every SCSS file so `@media (max-width: $tablet)`
// works in any *.scss / *.module.scss. Source of truth: src/assets/theme/breakpoints.ts
const scssBreakpoints = Object.entries(BREAKPOINTS_PX)
  .map(([name, px]) => `$${name}: ${px}px;`)
  .join(' ');

const scssGlobalPreamble = `@use "assets/styles/cascade-layers" as *; @use "assets/styles/mixins" as *; ${scssBreakpoints}`;

/** Header widget mixins — not global; see src/widgets/header/styles/_mixins.scss */
function scssAdditionalData(content: string, filename: string): string {
  const normalized = filename.replace(/\\/g, '/');
  const isHeaderStyles =
    normalized.includes('/widgets/header/styles/') &&
    !normalized.endsWith('/widgets/header/styles/_mixins.scss');
  const headerMixins = isHeaderStyles ? `@use "widgets/header/styles/mixins" as *; ` : '';

  return `${scssGlobalPreamble} ${headerMixins}${content}`;
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiTarget = env.VITE_APP_URL.length > 0 ? env.VITE_APP_URL : env.VITE_LOBBY_API_URL;
  const isProd = mode === 'production';
  const shouldAnalyze = env.VITE_ANALYZE === 'true';
  return {
    plugins: [
      react(),
      fontsStylesheetPlugin(),
      themeBuildPlugin(),
      shouldAnalyze
        ? visualizer({
            filename: 'dist/stats.html',
            open: false,
            gzipSize: true,
            brotliSize: true,
          })
        : null,
    ].filter(Boolean),
    server: {
      proxy: {
        '/apiLobby.php': {
          target: apiTarget,
          changeOrigin: true,
        },
        '/api.php': {
          target: apiTarget,
          changeOrigin: true,
        },
      },
    },
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
        '@ui': fileURLToPath(new URL('./src/shared/ui', import.meta.url)),
        '@shared': fileURLToPath(new URL('./src/shared', import.meta.url)),
        '@api': fileURLToPath(new URL('./src/api', import.meta.url)),
        '@store': fileURLToPath(new URL('./src/store', import.meta.url)),
        '@hooks': fileURLToPath(new URL('./src/hooks', import.meta.url)),
        '@pages': fileURLToPath(new URL('./src/pages', import.meta.url)),
      },
    },
    build: {
      target: 'es2022',
      cssTarget: ['chrome90', 'edge90', 'firefox90', 'safari13', 'ios13', 'opera76'],
      cssCodeSplit: true,
      minify: 'esbuild',
      rollupOptions: {
        output: {
          manualChunks: (id) => {
            if (id.includes('node_modules')) {
              if (id.includes('react-dom') || id.includes('/react/')) return 'react';
              if (id.includes('react-router')) return 'router';
              if (id.includes('@reduxjs/toolkit') || id.includes('react-redux')) return 'redux';
              if (id.includes('@tanstack/react-query')) return 'query';
              if (id.includes('axios')) return 'axios';
            }
          },
          chunkFileNames: 'assets/[name]-[hash].js',
          entryFileNames: 'assets/[name]-[hash].js',
          assetFileNames: 'assets/[name]-[hash][extname]',
        },
      },
    },
    css: {
      modules: {
        generateScopedName: isProd ? '[hash:base64:8]' : '[name]_[local]_[hash:base64:5]',
      },
      preprocessorOptions: {
        scss: {
          loadPaths: [fileURLToPath(new URL('./src', import.meta.url))],
          additionalData: scssAdditionalData,
        },
      },
    },
    test: {
      globals: true,
      environment: 'jsdom',
      setupFiles: './src/setupTests.ts',
      include: ['src/**/*.{test,spec}.{ts,tsx}'],
      coverage: {
        provider: 'v8',
        reporter: ['text', 'html'],
      },
    },
  };
});
