# iGambling frontend — short AI contract (English)

Full rules: `.cursor/rules/devcasi-rules.mdc`, `.cursor/rules/ui-architecture.mdc`, `.cursor/rules/header-architecture-guard.mdc`.

## Stack

React 19 · Vite · TypeScript strict · TanStack Query (server) · Redux Toolkit (client only) · React Router 6 · SCSS Modules · Mantine (engine only).

## Layers (FSD)

`app → pages → widgets → features → entities → shared` — imports downward; cross-feature via `public.ts` only.

## Header Engine v4

`schema → layout → block(sync) → plugin → adapter(lazy) → entity → shared/ui`

- Sync registries: `layoutRegistry` + `blockRegistry` only.
- Lazy adapters: plugin `adapters` + `runtime/` only.
- Data: `useHeaderMenu` in `app/layouts/` only.
- No `if (isMobile)` / `switch(variant)` in JSX.

## State

- Server: TanStack Query (`staleTime`, `gcTime`, structured keys).
- Client Redux: auth, flags, locale — not API cache or modal state.
- Tokens: httpOnly cookies only.

## Subagents

`.cursor/agents/*.md` — `/engineer`, `/architect`, `/qa`, … See `.cursor/rules/cursor-agents-index.mdc`.

## Verify

`yarn lint` → `yarn build` → `yarn test` (targeted paths when possible).
