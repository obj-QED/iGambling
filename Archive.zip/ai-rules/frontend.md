# iGambling frontend — short AI contract (English)

Full rules: `.cursor/rules/devcasi-rules.mdc`, `.cursor/rules/ui-architecture.mdc`, `.cursor/rules/header-architecture-guard.mdc`, **`.cursor/rules/widget-component-patterns.mdc`** (shared + header + sidebar).

## Stack

React 19 · Vite · TypeScript strict · TanStack Query (server) · Redux Toolkit (client only) · React Router 6 · SCSS Modules · Mantine (engine only).

## Layers (FSD)

`app → pages → widgets → features → entities → shared` — imports downward; cross-feature via `public.ts` only.

## Header Engine v4

`schema → layout → block(sync) → plugin → adapter(lazy) → entity → shared/ui`

- Sync registries: `layoutRegistry` + `blockRegistry` only.
- Lazy adapters: plugin `adapters` + `runtime/` only.
- Data: `useHeaderMenu` in `app/layouts/` only.
- No `if (isMobile)` / `switch(variant)` in JSX.

## Sidebar (aside)

`settings.aside → resolveSidebarConfig → Root → type strategy → Shell → Block (sync registry) → menu/* → shared/ui`

- Same menu item model as header (`HeaderMenuItem`); media via **`CmfIcon`** (`shared/ui`).
- Dropdown open state: localStorage + context — not Redux.
- Details: `widget-component-patterns.mdc` (sidebar section).

## shared/ui

- Generic primitives only: **`AppLink`**, **`CmfIcon`**, overlays.
- Folder: `Component/Component.tsx` + `index.ts` + `styles.module.scss`.
- Inside component: named `function Component()` in `forwardRef` — no `ComponentComponent`; SCSS uses `.root`, not component name.
- CMF icons: `.svg` → inline SVG + `data-src`; attrs `data-cmf-icon-*`; global `cmf-inline-svg.scss`.

## State

- Server: TanStack Query (`staleTime`, `gcTime`, structured keys).
- Client Redux: auth, flags, locale — not API cache or modal state.
- Tokens: httpOnly cookies only.

## Subagents

`.cursor/agents/*.md` — `/engineer`, `/architect`, `/qa`, … See `.cursor/rules/cursor-agents-index.mdc`.

## Verify

`yarn lint` → `yarn build` → `yarn test` (targeted paths when possible).
