#!/usr/bin/env bash
# Sync iGambling subagents to ~/.cursor/agents (global Cursor).
# Copies only named agents (YAML frontmatter with `name:`), not README or shared contract.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GLOBAL_AGENTS="${HOME}/.cursor/agents"
SRC="${REPO_ROOT}/.cursor/agents"

mkdir -p "$GLOBAL_AGENTS"

count=0
for file in "${SRC}"/*.md; do
  [[ -f "$file" ]] || continue
  base="$(basename "$file")"
  case "$base" in
    README.md | _shared-contract.md) continue ;;
  esac
  if grep -q '^name:' "$file"; then
    cp "$file" "$GLOBAL_AGENTS/"
    count=$((count + 1))
  fi
done

chmod +x "${HOME}/.cursor/hooks/"*.sh 2>/dev/null || true

echo "Synced ${count} agent(s): ${SRC} -> ${GLOBAL_AGENTS}"
ls -1 "$GLOBAL_AGENTS"/*.md 2>/dev/null | wc -l | xargs echo "Global agent files:"
