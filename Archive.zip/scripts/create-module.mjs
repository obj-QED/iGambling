#!/usr/bin/env node
import path from 'node:path';
import process from 'node:process';

import { writeModule } from './create-module/generate.mjs';
import { buildMeta, resolveTarget } from './create-module/utils.mjs';

function printHelp() {
  console.log(`Create FSD module scaffold (header-like, no context/menu)

Usage:
  yarn scaffold path:ModuleName [--force]

  path     — parent folder (alias or src/... path; created if missing)
  ModuleName — folder name + all identifiers (App*, resolve*Config, types)

Preferred:
  yarn scaffold widget:Sidebar        → src/widgets/sidebar/
  yarn scaffold src/widgets:PromoBanner
  yarn scaffold src/features/auth:AuthPanel

Legacy (still supported):
  yarn scaffold widget Sidebar
  yarn scaffold src/widgets/promo

Aliases: widget, feature, page, entity, ui, component (+ plural forms)

Generated structure:
  config/ (defaults + resolve*Config)
  lib/ registry/ types/ ui/ styles/ public.ts index.ts __tests__/
`);
}

async function main() {
  const cwd = process.cwd();
  const args = process.argv.slice(2).filter((arg) => arg !== '--force');
  const force = process.argv.includes('--force');

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    printHelp();
    process.exit(args.length === 0 ? 1 : 0);
  }

  let target;
  try {
    target = resolveTarget(cwd, args);
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
    printHelp();
    process.exit(1);
  }

  const meta = buildMeta(target.kebabName);
  const files = await writeModule(target.dir, meta, { force });
  const relativeDir = path.relative(cwd, target.dir);
  const importBase = relativeDir.startsWith(`src${path.sep}`)
    ? `@/${relativeDir.slice(4).split(path.sep).join('/')}`
    : `@/${relativeDir.split(path.sep).join('/')}`;

  console.log(`\nCreated ${meta.appComponent} at ${relativeDir}/\n`);
  console.log(`  Module    : ${target.moduleName ?? target.kebabName}`);
  console.log(`  Folder    : ${target.kebabName}`);
  console.log(`  Component : ${meta.appComponent}`);
  console.log(`  Config    : ${meta.resolveConfig}() ← window.__SETTINGS__.${meta.camel}`);
  console.log(`  Types     : default | classic`);
  console.log(`  Layouts   : container | container-fluid`);
  console.log(`  Files     : ${files.length}\n`);
  console.log(`Import:\n  import { ${meta.appComponent}, ${meta.resolveConfig} } from '${importBase}';\n`);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
