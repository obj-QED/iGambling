import fs from 'node:fs/promises';
import path from 'node:path';

function file(relativePath, content) {
  return { relativePath, content };
}

export function buildFileTree(meta) {
  const m = meta;
  const t = m.Pascal;
  const c = m.camel;
  const screaming = t.replace(/([a-z])([A-Z])/g, '$1_$2').toUpperCase();

  return [
    file('index.ts', `export * from './public';\n`),
    file(
      'public.ts',
      `export { ${m.defaultsConst}, ${m.resolveConfig} } from './config';\nexport type {\n  ${m.propsType},\n  ${m.blockProps},\n  ${m.configType},\n  ${m.layoutKey},\n  ${m.menuItem},\n  ${m.menuModel},\n  ${m.sectionProps},\n  ${m.sectionType},\n  ${m.typeKey},\n} from './types';\nexport { ${m.rootComponent} as ${m.appExportName} } from './ui/${m.rootComponent}';\n`,
    ),
    file(
      'types/index.ts',
      `export type { ${m.configType}, ${m.layoutKey}, ${m.typeKey} } from './config.types';\nexport type {\n  ${m.blockProps},\n  ${m.menuItem},\n  ${m.menuModel},\n  ${m.propsType},\n  ${m.sectionProps},\n  ${m.sectionType},\n} from './props.types';\n`,
    ),
    file(
      'types/config.types.ts',
      `export type ${m.layoutKey} = 'container' | 'container-fluid';\n\nexport type ${m.typeKey} = 'default' | 'classic';\n\nexport type ${m.configType} = {\n  layout: ${m.layoutKey};\n  type: ${m.typeKey};\n};\n`,
    ),
    file(
      'types/props.types.ts',
      `import type { ${m.configType} } from './config.types';\n\nexport type ${m.menuItem} = {\n  key: string;\n  name: string;\n  url: string;\n};\n\nexport type ${m.sectionType} = {\n  key: string;\n  items: ${m.menuItem}[];\n};\n\nexport type ${m.menuModel} = {\n  sections: ${m.sectionType}[];\n};\n\nexport type ${m.propsType} = {\n  menu: ${m.menuModel};\n  config: ${m.configType};\n  className?: string;\n};\n\nexport type ${m.blockProps} = {\n  item: ${m.menuItem};\n};\n\nexport type ${m.sectionProps} = {\n  section: ${m.sectionType};\n};\n`,
    ),
    file(
      'config/index.ts',
      `export { ${m.defaultsConst} } from './defaults';\nexport { ${m.resolveConfig} } from './resolve';\n`,
    ),
    file(
      'config/defaults.ts',
      `import type { ${m.configType} } from '../types';\n\nexport const ${m.defaultsConst}: ${m.configType} = {\n  layout: 'container',\n  type: 'default',\n};\n`,
    ),
    file(
      'config/resolve.ts',
      `import type { ${m.configType}, ${m.layoutKey}, ${m.typeKey} } from '../types';\n\nimport { getSettings } from '@/shared/config';\nimport { pickUnionValue } from '@/shared/lib/coercion';\n\nimport { ${m.defaultsConst} } from './defaults';\n\nconst LAYOUT_KEYS = ['container', 'container-fluid'] as const satisfies readonly ${m.layoutKey}[];\nconst TYPE_KEYS = ['default', 'classic'] as const satisfies readonly ${m.typeKey}[];\n\n/** Resolves widget config from \`window.__SETTINGS__.${c}\` with defaults. */\nexport function ${m.resolveConfig}(settings = getSettings()): ${m.configType} {\n  const section = (settings as { ${c}?: Partial<${m.configType}> }).${c};\n\n  return {\n    layout: pickUnionValue(LAYOUT_KEYS, section?.layout, ${m.defaultsConst}.layout),\n    type: pickUnionValue(TYPE_KEYS, section?.type, ${m.defaultsConst}.type),\n  };\n}\n`,
    ),
    file('lib/index.ts', `/** Pure helpers for ${m.kebab} — no React, no API. */\n`),
    file(
      'registry/index.ts',
      `export { BLOCK_REGISTRY, resolveBlockComponent } from './blocks';\nexport { LAYOUT_REGISTRY } from './layouts';\nexport { TYPE_STRATEGY_REGISTRY } from './strategies';\n`,
    ),
    file(
      'registry/blocks.ts',
      `import type { ${m.blockProps}, ${m.menuItem} } from '../types';\nimport type { ComponentType } from 'react';\n\nimport { DefaultBlock } from '../ui/blocks/DefaultBlock/DefaultBlock';\n\nexport const BLOCK_REGISTRY: Record<'default', ComponentType<${m.blockProps}>> = {\n  default: DefaultBlock,\n};\n\nexport function resolveBlockComponent(_item: ${m.menuItem}): ComponentType<${m.blockProps}> {\n  return BLOCK_REGISTRY.default;\n}\n`,
    ),
    file(
      'registry/layouts.ts',
      `import type { ${m.layoutKey} } from '../types';\nimport type { ComponentType } from 'react';\n\nimport { ContainerFluidLayout } from '../ui/layouts/ContainerFluidLayout/ContainerFluidLayout';\nimport { ContainerLayout } from '../ui/layouts/ContainerLayout/ContainerLayout';\n\nexport const LAYOUT_REGISTRY: Record<\n  ${m.layoutKey},\n  ComponentType<{ children: React.ReactNode }>\n> = {\n  container: ContainerLayout,\n  'container-fluid': ContainerFluidLayout,\n};\n`,
    ),
    file(
      'registry/strategies.ts',
      `import type { ${m.propsType}, ${m.typeKey} } from '../types';\nimport type { ComponentType } from 'react';\n\nimport { ClassicTypeStrategy } from '../ui/type/ClassicTypeStrategy';\nimport { DefaultTypeStrategy } from '../ui/type/DefaultTypeStrategy';\n\nexport const TYPE_STRATEGY_REGISTRY: Record<${m.typeKey}, ComponentType<${m.propsType}>> = {\n  default: DefaultTypeStrategy,\n  classic: ClassicTypeStrategy,\n};\n`,
    ),
    file(
      `ui/${m.rootComponent}.tsx`,
      `import type { ${m.propsType} } from '../types';\n\nimport { memo } from 'react';\n\nimport clsx from 'clsx';\n\nimport { TYPE_STRATEGY_REGISTRY } from '../registry/strategies';\n\nimport styles from '../styles/base/${m.rootComponent}.module.scss';\n\nfunction ${m.rootComponent}Component({ menu, config, className }: ${m.propsType}) {\n  const TypeStrategy = TYPE_STRATEGY_REGISTRY[config.type];\n\n  return (\n    <${m.rootElement}\n      className={clsx(styles.root, className)}\n      data-widget="${m.kebab}"\n      data-layout={config.layout}\n      data-type={config.type}\n    >\n      <TypeStrategy menu={menu} config={config} />\n    </${m.rootElement}>\n  );\n}\n\nexport const ${m.rootComponent} = memo(${m.rootComponent}Component);\n${m.rootComponent}.displayName = '${m.rootComponent}';\n`,
    ),
    file(
      `ui/${m.shell}.tsx`,
      `import type { ${m.propsType} } from '../types';\n\nimport { memo } from 'react';\n\nimport { Group } from '@mantine/core';\n\nimport { LAYOUT_REGISTRY } from '../registry/layouts';\n\nimport { ${m.section} } from './${m.section}';\n\nimport styles from '../styles/base/${m.shell}.module.scss';\n\ntype ${m.shell}Props = Pick<${m.propsType}, 'menu' | 'config'>;\n\nfunction ${m.shell}Component({ menu, config }: ${m.shell}Props) {\n  const Layout = LAYOUT_REGISTRY[config.layout];\n\n  return (\n    <Layout>\n      <Group className={styles.sections} justify="space-between" wrap="nowrap" gap="md">\n        {menu.sections.map((section) => (\n          <${m.section} key={section.key} section={section} />\n        ))}\n      </Group>\n    </Layout>\n  );\n}\n\nexport const ${m.shell} = memo(${m.shell}Component);\n${m.shell}.displayName = '${m.shell}';\n`,
    ),
    file(
      `ui/${m.section}.tsx`,
      `import type { ${m.sectionProps} } from '../types';\n\nimport { memo } from 'react';\n\nimport { Group } from '@mantine/core';\n\nimport { ${m.block} } from './${m.block}';\n\nimport styles from '../styles/base/${m.section}.module.scss';\n\nfunction ${m.section}Component({ section }: ${m.sectionProps}) {\n  return (\n    <Group className={styles.root} gap="xs" wrap="nowrap" data-section-key={section.key}>\n      {section.items.map((item) => (\n        <${m.block} key={item.key} item={item} />\n      ))}\n    </Group>\n  );\n}\n\nexport const ${m.section} = memo(${m.section}Component);\n${m.section}.displayName = '${m.section}';\n`,
    ),
    file(
      `ui/${m.block}.tsx`,
      `import type { ${m.blockProps} } from '../types';\n\nimport { memo } from 'react';\n\nimport { resolveBlockComponent } from '../registry/blocks';\n\nfunction ${m.block}Component({ item }: ${m.blockProps}) {\n  const BlockComponent = resolveBlockComponent(item);\n  return <BlockComponent item={item} />;\n}\n\nexport const ${m.block} = memo(${m.block}Component);\n${m.block}.displayName = '${m.block}';\n`,
    ),
    file(
      'ui/blocks/DefaultBlock/DefaultBlock.tsx',
      `import type { ${m.blockProps} } from '../../../types';\n\nimport { memo } from 'react';\n\nimport styles from '../../../styles/blocks/DefaultBlock.module.scss';\n\nfunction DefaultBlockComponent({ item }: ${m.blockProps}) {\n  return (\n    <div className={styles.root} data-block-key={item.key}>\n      element default\n    </div>\n  );\n}\n\nexport const DefaultBlock = memo(DefaultBlockComponent);\nDefaultBlock.displayName = 'DefaultBlock';\n`,
    ),
    file(
      'ui/layouts/ContainerLayout/ContainerLayout.tsx',
      `import { memo, type ReactNode } from 'react';\n\nimport { Container } from '@mantine/core';\n\nimport styles from '../../../styles/layout/ContainerLayout.module.scss';\n\ntype ContainerLayoutProps = {\n  children: ReactNode;\n};\n\nfunction ContainerLayoutComponent({ children }: ContainerLayoutProps) {\n  return (\n    <Container className={styles.root} size="responsive">\n      {children}\n    </Container>\n  );\n}\n\nexport const ContainerLayout = memo(ContainerLayoutComponent);\nContainerLayout.displayName = 'ContainerLayout';\n`,
    ),
    file(
      'ui/layouts/ContainerFluidLayout/ContainerFluidLayout.tsx',
      `import { memo, type ReactNode } from 'react';\n\nimport { Container } from '@mantine/core';\n\nimport styles from '../../../styles/layout/ContainerFluidLayout.module.scss';\n\ntype ContainerFluidLayoutProps = {\n  children: ReactNode;\n};\n\nfunction ContainerFluidLayoutComponent({ children }: ContainerFluidLayoutProps) {\n  return (\n    <Container className={styles.root} fluid>\n      {children}\n    </Container>\n  );\n}\n\nexport const ContainerFluidLayout = memo(ContainerFluidLayoutComponent);\nContainerFluidLayout.displayName = 'ContainerFluidLayout';\n`,
    ),
    file(
      'ui/type/DefaultTypeStrategy.tsx',
      `import type { ${m.propsType} } from '../../types';\n\nimport { memo } from 'react';\n\nimport { ${m.shell} } from '../${m.shell}';\n\nfunction DefaultTypeStrategyComponent({ menu, config }: ${m.propsType}) {\n  return <${m.shell} menu={menu} config={config} />;\n}\n\nexport const DefaultTypeStrategy = memo(DefaultTypeStrategyComponent);\nDefaultTypeStrategy.displayName = 'DefaultTypeStrategy';\n`,
    ),
    file(
      'ui/type/ClassicTypeStrategy.tsx',
      `import type { ${m.propsType} } from '../../types';\n\nimport { memo } from 'react';\n\nimport clsx from 'clsx';\n\nimport { ${m.shell} } from '../${m.shell}';\n\nimport styles from '../../styles/variant/type-classic.module.scss';\n\nfunction ClassicTypeStrategyComponent({ menu, config }: ${m.propsType}) {\n  return (\n    <div className={clsx(styles.root)} data-type-strategy="classic">\n      <${m.shell} menu={menu} config={config} />\n    </div>\n  );\n}\n\nexport const ClassicTypeStrategy = memo(ClassicTypeStrategyComponent);\nClassicTypeStrategy.displayName = 'ClassicTypeStrategy';\n`,
    ),
    file(
      'styles/_layers.scss',
      `// ${t} widget SCSS layers (nested under global \`widget\`).\n// widget.base | widget.layout | widget.blocks | widget.variant\n`,
    ),
    file(
      `styles/base/${m.rootComponent}.module.scss`,
      `@use '../variant/type-default';\n\n@layer widget.base {\n  .root {\n    width: 100%;\n  }\n}\n`,
    ),
    file(
      `styles/base/${m.shell}.module.scss`,
      `@layer widget.base {\n  .sections {\n    width: 100%;\n  }\n}\n`,
    ),
    file(
      `styles/base/${m.section}.module.scss`,
      `@layer widget.base {\n  .root {\n    min-width: 0;\n  }\n}\n`,
    ),
    file(
      'styles/layout/ContainerLayout.module.scss',
      `@layer widget.layout {\n  .root {\n    width: 100%;\n  }\n}\n`,
    ),
    file(
      'styles/layout/ContainerFluidLayout.module.scss',
      `@layer widget.layout {\n  .root {\n    width: 100%;\n  }\n}\n`,
    ),
    file(
      'styles/blocks/DefaultBlock.module.scss',
      `@layer widget.blocks {\n  .root {\n    min-width: 0;\n  }\n}\n`,
    ),
    file(
      'styles/variant/index.scss',
      `@forward 'type-default';\n`,
    ),
    file(
      'styles/variant/type-default.scss',
      `@layer widget.variant {\n  .root[data-type='default'] {\n    --${m.cssPrefix}-surface-bg: transparent;\n  }\n}\n`,
    ),
    file(
      'styles/variant/type-classic.module.scss',
      `@layer widget.variant {\n  .root {\n    width: 100%;\n  }\n}\n`,
    ),
    file(
      '__tests__/resolve.test.ts',
      `import { describe, expect, it } from 'vitest';\n\nimport { ${m.resolveConfig} } from '../config/resolve';\n\ndescribe('${m.resolveConfig}', () => {\n  it('returns defaults when settings section is missing', () => {\n    expect(${m.resolveConfig}({})).toEqual({ layout: 'container', type: 'default' });\n  });\n\n  it('reads layout and type from settings', () => {\n    expect(\n      ${m.resolveConfig}({\n        ${c}: { layout: 'container-fluid', type: 'classic' },\n      } as never),\n    ).toEqual({ layout: 'container-fluid', type: 'classic' });\n  });\n});\n`,
    ),
  ];
}

export async function writeModule(baseDir, meta, { force = false } = {}) {
  const files = buildFileTree(meta);

  try {
    const stat = await fs.stat(baseDir);
    if (stat.isDirectory()) {
      const entries = await fs.readdir(baseDir);
      if (entries.length > 0 && !force) {
        throw new Error(
          `Target directory is not empty: ${baseDir}\nUse --force to scaffold into a non-empty directory.`,
        );
      }
    }
  } catch (error) {
    if (/** @type {NodeJS.ErrnoException} */ (error).code !== 'ENOENT') {
      throw error;
    }
  }

  await fs.mkdir(baseDir, { recursive: true });

  for (const entry of files) {
    const fullPath = path.join(baseDir, entry.relativePath);
    await fs.mkdir(path.dirname(fullPath), { recursive: true });
    await fs.writeFile(fullPath, entry.content, 'utf8');
  }

  return files.map((entry) => entry.relativePath);
}
