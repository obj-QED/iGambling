# Cursor — project + global setup

## Project (this repo)

| Path                  | Role                                            |
| --------------------- | ----------------------------------------------- |
| `.cursor/rules/*.mdc` | Full devcasi / iGambling architecture (English) |
| `.cursor/agents/*.md` | Subagents (`/engineer`, `/architect`, …)        |
| `.cursor/hooks.json`  | Format-on-edit + subagent routing for this repo |

## Global (all workspaces on this machine)

| Path                           | Role                                                          |
| ------------------------------ | ------------------------------------------------------------- |
| `~/.cursor/rules/global-*.mdc` | English, compression, workflow baseline                       |
| `~/.cursor/agents/*.md`        | Same subagents (sync from this repo)                          |
| `~/.cursor/hooks.json`         | Format + routing; **delegates** to project hooks when present |

## Sync agents to global

```bash
./scripts/sync-cursor-global.sh
```

Run after changing `.cursor/agents/*.md`.

## Enable hooks

1. Open **Cursor → Settings → Hooks** — confirm user hooks are loaded.
2. Trust this workspace so **project** hooks in `.cursor/hooks.json` also run.
3. Restart Cursor if hooks do not appear after editing `hooks.json`.

## Priority

**Project rules** override global defaults for architecture. **Global rules** set English for rules/commits and L2 compression unless you ask otherwise in chat.
