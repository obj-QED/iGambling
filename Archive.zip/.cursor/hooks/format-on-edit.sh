#!/usr/bin/env bash
# Auto-format after Agent or Tab edits. Runs from project root.
set -euo pipefail

json_input=$(cat)
file_path=$(printf '%s' "$json_input" | python3 -c "import sys, json; print(json.load(sys.stdin).get('file_path', ''))" 2>/dev/null || true)

if [[ -z "${file_path:-}" || ! -f "$file_path" ]]; then
  exit 0
fi

case "$file_path" in
  *node_modules*|*.min.*|yarn.lock|package-lock.json) exit 0 ;;
esac

ext="${file_path##*.}"
case "$ext" in
  ts|tsx|js|jsx|mjs|cjs)
    yarn eslint --fix "$file_path" 2>/dev/null || true
    yarn prettier --write "$file_path" 2>/dev/null || true
    ;;
  json|md|mdc)
    yarn prettier --write "$file_path" 2>/dev/null || true
    ;;
  scss|css)
    yarn stylelint --fix "$file_path" 2>/dev/null || true
    yarn prettier --write "$file_path" 2>/dev/null || true
    ;;
esac

exit 0
