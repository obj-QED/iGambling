#!/usr/bin/env bash
# After Agent Write: suggest which project subagent fits the edited file type.
set -euo pipefail

json_input=$(cat)
read -r tool_name file_path <<<"$(printf '%s' "$json_input" | python3 -c "
import json, sys
d = json.load(sys.stdin)
name = d.get('tool_name', '')
inp = d.get('tool_input') or {}
path = inp.get('path') or inp.get('file_path') or ''
print(name, path)
" 2>/dev/null || echo '')"

if [[ "$tool_name" != "Write" || -z "${file_path:-}" ]]; then
  exit 0
fi

case "$file_path" in
  *node_modules*) exit 0 ;;
esac

subagent=""
ext="${file_path##*.}"

case "$ext" in
  ts|tsx)
    if [[ "$file_path" == *".test."* || "$file_path" == *".spec."* || "$file_path" == *__tests__* ]]; then
      subagent="qa"
    elif [[ "$file_path" == *"/api/"* || "$file_path" == *"/queries/"* || "$file_path" == *"/mutations/"* ]]; then
      subagent="optimization"
    elif [[ "$file_path" == *"/widgets/header/"* ]]; then
      subagent="architect"
    elif [[ "$file_path" == *"/shared/ui/"* ]]; then
      subagent="ui"
    elif [[ "$file_path" == *"/ui/"* ]]; then
      subagent="comp"
    elif [[ "$file_path" == vite.config.* ]]; then
      subagent="performance"
    elif [[ "$file_path" == eslint* || "$file_path" == *tsconfig* ]]; then
      subagent="dx-standards"
    else
      subagent="engineer"
    fi
    ;;
  scss|css)
    subagent="ui"
    ;;
  *)
    exit 0
    ;;
esac

printf '%s\n' "{\"additional_context\": \"[format-agent-routing] File edited: ${file_path}. Preferred subagent for follow-up work: /${subagent}. File was auto-formatted by afterFileEdit hook (eslint/prettier/stylelint as applicable).\"}"
exit 0
