---
name: create
description: Scaffold FSD module — path:ModuleName (widget/feature/custom path)
---

# /create — module scaffold

Primary syntax (**path : module name**):

```bash
yarn scaffold path:ModuleName [--force]
```

| Part         | Meaning                                                             |
| ------------ | ------------------------------------------------------------------- |
| `path`       | Parent directory (alias or `src/...`; created if missing)           |
| `ModuleName` | Folder name (kebab) + all symbols (`App*`, `resolve*Config`, types) |

## Examples

```bash
yarn scaffold widget:Sidebar
# → src/widgets/sidebar/  AppSidebar, resolveSidebarConfig

yarn scaffold src/widgets:PromoBanner
# → src/widgets/promo-banner/

yarn scaffold src/features/auth:AuthPanel
# → src/features/auth/auth-panel/

yarn scaffold ui:AppLink
# → src/shared/ui/app-link/
```

> Do **not** use `yarn create` — Yarn 4 runs `create-*` npm packages.

## Aliases for `path`

`widget`, `widgets`, `feature`, `features`, `page`, `pages`, `entity`, `entities`, `ui`, `component`

## Legacy

```bash
yarn scaffold widget Sidebar
yarn scaffold src/widgets/promo
```

## Generated layout

```txt
<module>/
├── public.ts, index.ts
├── config/          defaults.ts, resolve.ts
├── lib/             pure helpers (role names, no module prefix)
├── registry/        blocks.ts, layouts.ts, strategies.ts
├── types/           config.types.ts, props.types.ts
├── ui/              Root.tsx, Shell, Section, Block, blocks/, layouts/, type/
├── styles/          base, layout, blocks, menu, variant
└── __tests__/       resolve.test.ts
```

### File naming (internal)

Folder = module context (`widgets/header/`). **Do not repeat the module name in filenames.**

| Folder      | Files (examples)                             | Public exports keep full names |
| ----------- | -------------------------------------------- | ------------------------------ |
| `config/`   | `defaults.ts`, `resolve.ts`                  | `resolveHeaderConfig`          |
| `lib/`      | `mapMenu.ts`, `mergeBlocks.ts`               | `mapRoot`                      |
| `registry/` | `blocks.ts`, `layouts.ts`, `keys.ts`         | `BLOCK_REGISTRY`               |
| `context/`  | `context.ts`, `provider.tsx`, `useConfig.ts` | `ConfigProvider`               |
| `types/`    | `config.types.ts`, `items.types.ts`          | `HeaderConfig`                 |
| `ui/menu/`  | `ItemButton`, `Dropdown`, `icons/Icons`      | —                              |

Scaffold: `ui/Root.tsx` exported as `App{Module}` from `public.ts`; no `Header`/`Menu` prefixes inside the widget folder.

## Settings

```js
sidebar: { layout: 'container-fluid', type: 'classic' },
```

Key = camelCase module name (`sidebar`, `promoBanner`, …).
