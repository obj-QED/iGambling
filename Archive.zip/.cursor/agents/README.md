# Cursor agents (this repo)

Markdown files with YAML `name` + `description` define **named subagents** in the Agent picker. The body is the **system prompt** for that role.

**Not subagents** (excluded from global sync):

- **`README.md`** — this file
- **`_shared-contract.md`** — shared boundaries referenced by agent prompts (no YAML frontmatter)

## Shared contract

- **`_shared-contract.md`** — stack, boundaries, verification, suggested pipeline.

## Rules stack

- Always-on: `.cursor/rules/devcasi-rules.mdc`
- Roster index: `.cursor/rules/cursor-agents-index.mdc`
- File-type routing (auto-attached): `.cursor/rules/agent-route-*.mdc`

## Format + subagent routing (hooks)

Project hooks live in `.cursor/hooks.json`:

| Hook                            | Script                               | Behavior                                                                     |
| ------------------------------- | ------------------------------------ | ---------------------------------------------------------------------------- |
| `afterFileEdit`                 | `hooks/format-on-edit.sh`            | After Agent edits: eslint/prettier or stylelint/prettier by extension        |
| `afterTabFileEdit`              | `hooks/format-on-edit.sh`            | Same for Tab inline edits                                                    |
| `postToolUse` (matcher `Write`) | `hooks/suggest-subagent-on-write.sh` | Injects `additional_context` with preferred `/subagent` for the written file |

**Manual invoke:** in Agent chat, type `/` + name (e.g. `/engineer`, `/architect`).

**Auto-delegation:** the parent Agent reads each file’s `description` field.

**File-context hints:** rules under `.cursor/rules/agent-route-*.mdc` attach when matching files are in context.

Reload hooks after editing `hooks.json` (save file or restart Cursor). Check **Settings → Hooks** and the Hooks output channel if something does not run.

## Agent roster

| File              | `name`       | Use when                                            |
| ----------------- | ------------ | --------------------------------------------------- |
| `orchestrator.md` | orchestrator | Run parallel specialists and merge one answer       |
| `architect.md`    | architect    | FSD/FDD boundaries, Header Engine v4 contracts      |
| `engineer.md`     | engineer     | Default implementation (`.ts`/`.tsx`)               |
| `ui.md`           | ui           | shared/ui, overlays, a11y, `.scss`                  |
| `comp.md`         | comp         | Component decomposition, `public.ts`, pure `ui/`    |
| `qa.md`           | qa           | Vitest/RTL/Playwright, contract tests               |
| `performance.md`  | performance  | Profiler/bundle/Query tuning — measure first        |
| `optimization.md` | optimization | TanStack Query keys/cache/invalidation              |
| `dx-standards.md` | dx-standards | ESLint/TS boundaries, naming, CI-minded consistency |

## Suggested pipeline

```text
orchestrator ──► architect + ui + optimization + dx-standards (parallel)
            └──► engineer ──► qa ──► performance
```

## Frontmatter

- **`model: inherit`** — subagent uses the parent Agent model (default for teams).
- **`model: <id>`** — pin a model (must exist in your Cursor build).
- **`readonly: true`** — audit-only (no file edits).
- **`is_background: true`** — runs without blocking the parent.

## Global Cursor (all workspaces)

Sync these agents to `~/.cursor/agents/`:

```bash
./scripts/sync-cursor-global.sh
```

See `.cursor/GLOBAL_SETUP.md` and `~/.cursor/README.md`.

## Verify after substantive code changes

`yarn lint` → `yarn build` → targeted `yarn test`
