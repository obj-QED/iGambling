# devcasi agents — shared contract

> Not a subagent — included by reference from agent prompts. Do not add YAML frontmatter here.

## Non‑negotiables

- Follow `.cursor/rules/devcasi-rules.mdc`, `.cursor/rules/ui-architecture.mdc`, `.cursor/rules/header-architecture-guard.mdc`, `.cursor/rules/devcasi-subagents-enterprise.mdc`.
- Keep FSD flow: `app → pages → widgets → features → entities → shared`.
- Feature boundary = `public.ts`. Cross-feature imports only via `public.ts` (or module `index.ts` re-exporting it).
- Header Engine v4 (`src/widgets/header/`):
  - `registry/`: only `layoutRegistry` + `blockRegistry` (sync)
  - `plugins/`: installable modules (`defineHeaderPlugin`, lazy `adapters`)
  - `engine/` + `sdk/` + `runtime/`: core, public API, adapter factory
  - Lazy adapters only via plugin contract + `runtime/` — never in blocks
- No `if (isMobile)` / `switch(variant)` trees in JSX.
- No API calls / `useQuery` inside `ui/` components.
- No server cache in Redux. Tokens only httpOnly cookies.

## Output expectations (all agents)

- Prefer small diffs and explicit contracts (types, unions, keys).
- When proposing structure: include exact paths to create/change.
- When changing contracts: update all consumers/tests in the same change set.

## Format-on-edit + subagent routing

- `.cursor/hooks.json` auto-formats Agent/Tab writes (eslint/prettier or stylelint/prettier).
- `postToolUse` on **Write** suggests a preferred `/subagent` in `additional_context`.
- File-scoped hints: `.cursor/rules/agent-route-*.mdc` (attached when matching files are in context).
