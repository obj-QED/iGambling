# iGambling visual reference

Read this when the spec needs exact token names or breakpoint values.

## Source files

| Concern             | Path                                             |
| ------------------- | ------------------------------------------------ |
| Design tokens (SoT) | `src/assets/theme/tokens/theme.scss`             |
| Breakpoints (px)    | `src/assets/theme/breakpoints.ts`                |
| Mantine bridge      | `src/assets/theme/mantine/mantineTheme.ts`       |
| Brand palette       | `src/assets/theme/mantine/brandPalette.ts`       |
| Button tokens       | `src/assets/theme/tokens/cmf-button-tokens.scss` |
| Header tokens       | `src/assets/theme/tokens/header-tokens.scss`     |

## Breakpoints (px)

| Name   | Max width | Typical use           |
| ------ | --------- | --------------------- |
| mobile | 767       | Phone layouts         |
| tablet | 1024      | Tablet / small laptop |
| laptop | 1440      | Desktop               |
| pc     | 1441+     | Wide desktop          |

SCSS (injected globally): `@media (max-width: $tablet) { ... }`

## Core CSS variables (`:root`)

### Color

| Token                | Light (default) |
| -------------------- | --------------- |
| `--color-primary`    | `#0d9488`       |
| `--color-text`       | `#0f172a`       |
| `--color-text-muted` | `#64748b`       |
| `--color-bg-body`    | `#fff`          |
| `--color-border`     | `#e2e8f0`       |

Dark mode: `[data-theme='dark']` / `[data-mantine-color-scheme='dark']` — see `theme.scss`.

### Spacing

| Token          | Value |
| -------------- | ----- |
| `--spacing-xs` | 4px   |
| `--spacing-sm` | 8px   |
| `--spacing-md` | 16px  |
| `--spacing-lg` | 24px  |
| `--spacing-xl` | 32px  |

### Radius

| Token         | Value |
| ------------- | ----- |
| `--radius-sm` | 6px   |
| `--radius-md` | 8px   |
| `--radius-lg` | 12px  |

### Shadow

| Token         | Use              |
| ------------- | ---------------- |
| `--shadow-sm` | Subtle elevation |
| `--shadow-md` | Cards, dropdowns |
| `--shadow-lg` | Modals, overlays |

### Z-index

| Token                | Value |
| -------------------- | ----- |
| `--z-index-dropdown` | 200   |
| `--z-index-sticky`   | 300   |
| `--z-index-overlay`  | 400   |
| `--z-index-modal`    | 500   |

### Typography

| Token                               | Value            |
| ----------------------------------- | ---------------- |
| `--font-family-base`                | IBM Plex Sans    |
| `--font-family-headings`            | Georgia          |
| `--h1-font-size` … `--h6-font-size` | See `theme.scss` |

### Container

| Token                              | Value               |
| ---------------------------------- | ------------------- |
| `--container-max-mobile`           | 100%                |
| `--container-max-tablet`           | 768px               |
| `--container-max-laptop`           | 1240px              |
| `--container-max-pc`               | 1680px              |
| `--root-container-padding-desktop` | `var(--spacing-md)` |
| `--root-container-padding-mobile`  | `var(--spacing-xs)` |

## SCSS module conventions

```scss
@layer fdd-base {
  .root {
    padding: var(--spacing-md);
    color: var(--color-text);
  }
}

@layer fdd-variant {
  .root--compact {
    padding: var(--spacing-sm);
  }
}
```

- Max BEM nesting: one level (`&__element`, `&--modifier`)
- Component-scoped overrides: `--<component>-<property>` with fallback to global token
- Use `content()` helper where the codebase already does for theme injection

## Responsive architecture (spec language)

| User says                                    | Spec should prescribe                                                      |
| -------------------------------------------- | -------------------------------------------------------------------------- |
| "Stack on mobile"                            | CSS: `flex-direction`, `gap`, `order`                                      |
| "Drawer instead of popover on small screens" | Schema: `wrapper: 'drawer'` or `blockVariants` adapter — not two JSX trees |
| "Hide label on narrow"                       | CSS: `visibility` / `clip` — keep accessible name                          |

## Mantine usage in specs

- Reference Mantine **components** (Button, ActionIcon, Popover) as implementation primitives
- Visual values still come from CSS variables / theme tokens — not ad-hoc Mantine color props in the spec unless mapping to a token
