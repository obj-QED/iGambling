---
name: design-visual-web-app
description: Produces written visual design specs for iGambling web UI — layout mockups, design tokens, component anatomy, responsive strategy, a11y, and asset briefs. Use when the user asks to design visuals, mockups, UI look-and-feel, spacing, hierarchy, themes, or screen layouts before implementation.
---

# Design Visual for Web App (iGambling)

## Purpose

Turn a UI goal into an **implementation-ready visual spec** — not production code first.

Default deliverable: **written design spec**. Code, SCSS, and Canvas come only after the user approves or explicitly asks to implement.

---

## When to use

- New screen, widget section, or component appearance
- Visual refresh, density/spacing changes, dark/light tuning
- Responsive layout decisions (structure vs behavior)
- Token gaps (new spacing, color, radius needs)
- Asset briefs (icons, illustrations, marketing tiles)

**Do not use for:** business logic, API design, routing, or architecture refactors — use `frontend-delivery` / `/architect` instead.

---

## Workflow

Copy and track:

```
Design progress:
- [ ] 1. Scope & constraints
- [ ] 2. Inventory existing tokens/patterns
- [ ] 3. Layout & hierarchy
- [ ] 4. Tokens & states
- [ ] 5. Responsive strategy
- [ ] 6. A11y & motion
- [ ] 7. Assets (if any)
- [ ] 8. Publish spec
```

### 1. Scope & constraints

Clarify (ask only if missing):

| Question                                   | Why                                |
| ------------------------------------------ | ---------------------------------- |
| What surface? (page / widget / component)  | Bounds the spec                    |
| Primary user action?                       | Drives hierarchy                   |
| Light, dark, or both?                      | Token mapping                      |
| Reference (screenshot, competitor, Figma)? | Align expectations                 |
| Must reuse existing primitives?            | Prefer `shared/ui`, Mantine bridge |

**Hard constraints (iGambling):**

- Tokens SoT: `src/assets/theme/tokens/theme.scss`
- Styles: CSS Modules + SCSS, `@layer fdd-base` / `fdd-variant`
- Structural responsive → CSS only (`flex`, `order`, `visibility`, breakpoints)
- Behavioral responsive → schema/adapters — **never** duplicated desktop/mobile JSX trees
- Mantine = rendering engine; visual values come from CSS variables
- No magic numbers — map to `--spacing-*`, `--radius-*`, `--color-*`

### 2. Inventory

Before inventing values, read:

- `src/assets/theme/tokens/theme.scss` — colors, spacing, radii, shadows, z-index
- `src/assets/theme/breakpoints.ts` — mobile 767, tablet 1024, laptop 1440, pc 1441
- Nearest existing component styles in the same layer (`shared/ui`, `widgets/*`, `entities/*`)
- Header/widget rules if touching header: `.cursor/rules/header-architecture-guard.mdc`

Full token tables: [reference.md](reference.md)

### 3. Layout & hierarchy

Express structure as **ascii** or **mermaid** — not pixel-perfect Figma.

Rules:

- One primary focal point per viewport
- Group related controls; separate destructive/primary actions
- Align to container tokens (`--container-max-*`, padding desktop/mobile)
- Name regions (header, toolbar, content, aside) — maps to FSD layers later

### 4. Tokens & component anatomy

For each visual element specify:

| Field           | Example                                                                |
| --------------- | ---------------------------------------------------------------------- |
| Element role    | Primary CTA, meta label, icon trigger                                  |
| Token bindings  | `padding: var(--spacing-md)`, `color: var(--color-text-muted)`         |
| Typography      | `--h4-font-size` or body default                                       |
| Radius / shadow | `--radius-md`, `--shadow-sm`                                           |
| States          | default, hover, focus-visible, active, disabled, loading, empty, error |
| Density         | compact / default / comfortable (via spacing scale only)               |

**New tokens:** propose name, value, and whether it belongs in `theme.scss` or a scoped `--component-*` prefix in the module.

### 5. Responsive strategy

Split explicitly:

| Type       | Mechanism                                  | Spec must say                                  |
| ---------- | ------------------------------------------ | ---------------------------------------------- |
| Structural | SCSS `@media (max-width: $tablet)`         | What reflows, hides, stacks                    |
| Behavioral | `blockVariants` / adapter choice in schema | Which representation loads per breakpoint band |

Forbidden in specs: "render MobileHeader + DesktopHeader with CSS hide."

### 6. A11y & motion

Minimum in every spec:

- Focus order and visible `:focus-visible` treatment
- Touch target ≥ 44×44px for primary actions (or justify exception)
- Contrast: body text ≥ 4.5:1; large text ≥ 3:1 against background
- Icon-only controls: `aria-label` requirement
- `prefers-reduced-motion`: no essential info in motion-only cues

### 7. Assets

When visuals need images/icons:

- List each asset: name, size (@1x/@2x), format (svg preferred for icons)
- Style brief: flat/gradient, stroke weight, corner radius alignment with `--radius-*`
- Use Cursor **GenerateImage** only when the user wants a generated reference or marketing visual — not for standard UI icons (prefer SVG components or existing icon set)

### 8. Publish spec

Use the template below. End with **Open questions** (max 3) only if blocked.

---

## Spec template

```markdown
# Visual spec: [Name]

## Summary

[1–2 sentences: what we're designing and for whom]

## Goals

- ...

## Layout

[ascii or mermaid diagram]

### Regions

| Region | Purpose | Layer (FSD)              |
| ------ | ------- | ------------------------ |
| ...    | ...     | shared / entity / widget |

## Visual hierarchy

1. ...
2. ...

## Tokens

| Usage           | Token             | Notes |
| --------------- | ----------------- | ----- |
| Page background | `--color-bg-body` |       |
| ...             | ...               |       |

### New tokens (if any)

| Token | Value | Rationale |
| ----- | ----- | --------- |

## Components

### [ComponentName]

- Anatomy: ...
- States: default | hover | focus | disabled | ...
- SCSS module path (proposed): `styles/...`

## Responsive

| Breakpoint | Structural (CSS) | Behavioral (schema/adapter) |
| ---------- | ---------------- | --------------------------- |
| ≤ tablet   | ...              | ...                         |

## Accessibility

- Focus: ...
- Contrast: ...
- Labels: ...

## Assets

| Asset | Spec | Format |
| ----- | ---- | ------ |

## Implementation handoff

- Suggested owner: `/ui` for primitives, `/engineer` for widget wiring
- Depends on: ...
- Out of scope: ...

## Open questions

- ...
```

---

## Optional follow-ups (user must ask)

| Request                    | Action                                                                    |
| -------------------------- | ------------------------------------------------------------------------- |
| "Implement it"             | Hand off to `frontend-delivery` or `/engineer` + `/ui` with spec attached |
| "Show me interactively"    | Read `canvas` skill; build `.canvas.tsx` mock **after** spec approval     |
| "Generate reference image" | GenerateImage with style brief from spec § Assets                         |

---

## Quality bar

Before publishing the spec:

- [ ] Every spacing/color uses an existing token or a proposed token with name
- [ ] Responsive split is structural vs behavioral
- [ ] All interactive elements have state + a11y notes
- [ ] No architecture violations (no API in UI, no `isMobile` JSX trees)
- [ ] Spec is actionable without guessing brand values

---

## Additional resources

- Token & breakpoint reference: [reference.md](reference.md)
- Implementation discipline: [frontend-delivery](../frontend-delivery/SKILL.md)
- UI architecture rules: `.cursor/rules/ui-architecture.mdc`
