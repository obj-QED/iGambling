# Cursor rules (English)

All rule files in this folder are written in **English**.

## Always applied

| File                               | Purpose                                                    |
| ---------------------------------- | ---------------------------------------------------------- |
| `devcasi-rules.mdc`                | Core stack, FSD, state, header, styling, security          |
| `widget-component-patterns.mdc`    | **shared/ui + header + sidebar** component layout & naming |
| `devcasi-subagents-enterprise.mdc` | Subagent roster + production architecture                  |
| `ui-architecture.mdc`              | UI layers, widgets, lazy loading, extension checklist      |
| `header-architecture-guard.mdc`    | Header Engine v4 (when `src/widgets/header/**` in context) |
| `response-compression.mdc`         | Reply compression levels (L1/L2/L3)                        |

## On demand / by glob

| File                      | Purpose                        |
| ------------------------- | ------------------------------ |
| `cursor-agents-index.mdc` | When to use which `/subagent`  |
| `mantine-patterns.mdc`    | Mantine + token bridge         |
| `agent-route-*.mdc`       | File-type → preferred subagent |

## Related

- Subagents: `.cursor/agents/`
- Hooks (format on edit): `.cursor/hooks.json`
- Short glossary: `ai-rules/frontend.md`
- Root summary: `.cursorrules`
