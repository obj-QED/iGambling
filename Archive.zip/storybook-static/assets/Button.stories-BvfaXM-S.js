import{B as n,j as e,M as I,C as P,a as j}from"./iframe-BrC--jVC.js";import{G as B,C as b}from"./CmfIcon-cXDjtVVC.js";import{S as c,T as f}from"./Stack-COJDyCZr.js";import{c as S,a as A}from"./cmfScopeOverrides-Dlj2pTxR.js";import{e as s,a as C}from"./elementStoryParameters-BoK8xJLb.js";import{m as D,V as _,M as w,B as O,a as x,b as k,c as h,d as N,e as z,f as M}from"./VariantMatrix-BvcldSbj.js";import"./preload-helper-gDVRIedU.js";import"./to-int-CdRLc0g2.js";const{useArgs:R}=__STORYBOOK_MODULE_PREVIEW_API__,T=[...I,...P.filter(t=>t!=="exception")],V="/uploads/jlogo.webp";function a({alt:t="demo"}){return e.jsx(b,{src:V,alt:t,shape:"rect",radius:"sm"})}const K={title:"Elements/Button",component:n,tags:["autodocs"],parameters:{layout:"padded",docs:{description:{component:"Mantine Button + CMF cascade. Icon media size: `--cmf-button[-{scope}]-icon-{scale|aspect|width|height}` → `--cmf-icon-*` → box × scale × aspect."}}},argTypes:{variant:x(T),color:M(),size:z(j),radius:N(),disabled:h(),loading:h(),fullWidth:h("Layout"),children:k("children"),iconScale:x(["0.5","0.7","1"],"Icon"),iconAspect:x(["1","1.5","2"],"Icon")},args:{children:"Button",variant:"filled",color:"brand",size:"md",radius:"md",disabled:!1,loading:!1,fullWidth:!1,iconScale:"0.7",iconAspect:"1"}},i={parameters:s},l={parameters:{...s,docs:{description:{story:"CmfIcon in `leftSection` — size from `--button-height` × scale × aspect."}}},render:t=>{const{iconScale:r,iconAspect:u,children:o,...g}=t;return e.jsx("div",{style:A({scale:r,aspect:u}),children:e.jsx(n,{...g,leftSection:e.jsx(a,{alt:String(o??"Button")}),children:o})})}},d={parameters:{...s,docs:{description:{story:"Token ladder demos. Prefer `--cmf-button-icon-*` / widget scope over bare `%` of row width."}}},render:()=>e.jsxs(c,{gap:"lg",align:"flex-start",children:[e.jsxs(c,{gap:"xs",children:[e.jsx(f,{size:"sm",fw:600,children:"scale 0.5 / 0.7 / 1 · aspect 1"}),e.jsx(B,{gap:"md",children:["0.5","0.7","1"].map(t=>e.jsx("div",{style:S("button",{scale:t,aspect:1}),children:e.jsx(n,{variant:"default",leftSection:e.jsx(a,{alt:`scale ${t}`}),children:t})},t))})]}),e.jsxs(c,{gap:"xs",children:[e.jsx(f,{size:"sm",fw:600,children:"aspect 1 / 1.5 / 2 · scale 0.7 (sidebar-like)"}),e.jsx(B,{gap:"md",children:["1","1.5","2"].map(t=>e.jsx("div",{style:S("button",{scale:.7,aspect:t}),children:e.jsx(n,{variant:"outline",leftSection:e.jsx(a,{alt:`aspect ${t}`}),children:t})},t))})]}),e.jsxs(c,{gap:"xs",children:[e.jsx(f,{size:"sm",fw:600,children:"explicit `--cmf-button-icon-height: 1.25rem`"}),e.jsx("div",{style:S("button",{height:"1.25rem",width:"1.875rem"}),children:e.jsx(n,{variant:"light",leftSection:e.jsx(a,{alt:"explicit size"}),children:"fixed"})})]})]})},m={parameters:{...s,docs:{...s.docs,description:{story:"Variant matrix for visual regression and token review."}}},render:()=>e.jsx(_,{items:T,columns:4,renderItem:t=>e.jsx(n,{variant:t,children:t})})},p={parameters:{...C,controls:D.controls},render:function(){const[r,u]=R(),{iconScale:o,iconAspect:g,children:y,...v}=r;return e.jsx(w,{args:r,fields:O,onChange:u,children:e.jsx("div",{style:A({scale:o,aspect:g}),children:e.jsx(n,{...v,leftSection:e.jsx(a,{alt:String(y??"Button")}),children:y})})})}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  parameters: elementDocsPreviewParameters
}`,...i.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      description: {
        story: 'CmfIcon in \`leftSection\` — size from \`--button-height\` × scale × aspect.'
      }
    }
  },
  render: args => {
    const {
      iconScale,
      iconAspect,
      children,
      ...buttonArgs
    } = args as ButtonStoryArgs;
    return <div style={cmfIconCascadeStyle({
      scale: iconScale,
      aspect: iconAspect
    })}>
        <Button {...buttonArgs} leftSection={<DemoButtonIcon alt={String(children ?? 'Button')} />}>
          {children}
        </Button>
      </div>;
  }
}`,...l.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      description: {
        story: 'Token ladder demos. Prefer \`--cmf-button-icon-*\` / widget scope over bare \`%\` of row width.'
      }
    }
  },
  render: () => <Stack gap="lg" align="flex-start">
      <Stack gap="xs">
        <Text size="sm" fw={600}>
          scale 0.5 / 0.7 / 1 · aspect 1
        </Text>
        <Group gap="md">
          {(['0.5', '0.7', '1'] as const).map(scale => <div key={scale} style={cmfControlIconCascadeStyle('button', {
          scale,
          aspect: 1
        })}>
              <Button variant="default" leftSection={<DemoButtonIcon alt={\`scale \${scale}\`} />}>
                {scale}
              </Button>
            </div>)}
        </Group>
      </Stack>
      <Stack gap="xs">
        <Text size="sm" fw={600}>
          aspect 1 / 1.5 / 2 · scale 0.7 (sidebar-like)
        </Text>
        <Group gap="md">
          {(['1', '1.5', '2'] as const).map(aspect => <div key={aspect} style={cmfControlIconCascadeStyle('button', {
          scale: 0.7,
          aspect
        }) as CSSProperties}>
              <Button variant="outline" leftSection={<DemoButtonIcon alt={\`aspect \${aspect}\`} />}>
                {aspect}
              </Button>
            </div>)}
        </Group>
      </Stack>
      <Stack gap="xs">
        <Text size="sm" fw={600}>
          explicit \`--cmf-button-icon-height: 1.25rem\`
        </Text>
        <div style={cmfControlIconCascadeStyle('button', {
        height: '1.25rem',
        width: '1.875rem'
      })}>
          <Button variant="light" leftSection={<DemoButtonIcon alt="explicit size" />}>
            fixed
          </Button>
        </div>
      </Stack>
    </Stack>
}`,...d.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      ...elementDocsPreviewParameters.docs,
      description: {
        story: 'Variant matrix for visual regression and token review.'
      }
    }
  },
  render: () => <VariantMatrix items={BUTTON_STORY_VARIANTS} columns={4} renderItem={variant => <Button variant={variant}>{variant}</Button>} />
}`,...m.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementPlaygroundParameters,
    controls: mantineDocsPlaygroundParameters.controls
  },
  render: function ButtonPlayground() {
    const [args, updateArgs] = useArgs<ButtonStoryArgs>();
    const {
      iconScale,
      iconAspect,
      children,
      ...buttonArgs
    } = args;
    return <MantineDocsPlayground args={args} fields={BUTTON_DOCS_PLAYGROUND_FIELDS} onChange={updateArgs}>
        <div style={cmfIconCascadeStyle({
        scale: iconScale,
        aspect: iconAspect
      })}>
          <Button {...buttonArgs} leftSection={<DemoButtonIcon alt={String(children ?? 'Button')} />}>
            {children}
          </Button>
        </div>
      </MantineDocsPlayground>;
  }
}`,...p.parameters?.docs?.source}}};const Z=["Default","WithIcon","IconCascade","AllVariants","Playground"];export{m as AllVariants,i as Default,d as IconCascade,p as Playground,l as WithIcon,Z as __namedExportsOrder,K as default};
