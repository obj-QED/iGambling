import{A as n,j as e,g as v,h as P,i as T}from"./iframe-BrC--jVC.js";import{G as I,C as j}from"./CmfIcon-cXDjtVVC.js";import{S as g,T as f}from"./Stack-COJDyCZr.js";import{c as y,a as C}from"./cmfScopeOverrides-Dlj2pTxR.js";import{e as c,a as O}from"./elementStoryParameters-BoK8xJLb.js";import{m as D,V as N,M as b,A as k,a as A,b as w,c as S,d as z,e as M,f as R}from"./VariantMatrix-BvcldSbj.js";import{c as V}from"./createReactComponent-hik4W6C4.js";import"./preload-helper-gDVRIedU.js";import"./to-int-CdRLc0g2.js";/**
 * @license @tabler/icons-react v3.44.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M12 5l0 14",key:"svg-0"}],["path",{d:"M5 12l14 0",key:"svg-1"}]],E=V("outline","plus","Plus",G),{useArgs:$}=__STORYBOOK_MODULE_PREVIEW_API__,x=[...v,...P],Y="/uploads/jlogo.webp";function h(){return e.jsx(E,{size:16,stroke:2})}function p({alt:a="demo"}){return e.jsx(j,{src:Y,alt:a,shape:"square",radius:"sm"})}const J={title:"Elements/ActionIcon",component:n,tags:["autodocs"],parameters:{layout:"padded",docs:{description:{component:"Mantine ActionIcon + CMF cascade. Icon size: `--cmf-action-icon[-{scope}]-icon-{scale|aspect|width|height}` → `--cmf-icon-*` → `--ai-size` × scale × aspect."}}},argTypes:{variant:A(x),color:R(),size:M(T),radius:z(),disabled:S(),loading:S(),"aria-label":w("aria-label"),iconScale:A(["0.5","0.7","1"],"Icon"),iconAspect:A(["1","1.5","2"],"Icon")},args:{variant:"default",color:"brand",size:"md",radius:"md",disabled:!1,loading:!1,"aria-label":"action",iconScale:"0.7",iconAspect:"1"}},t={parameters:c,render:a=>{const{iconScale:r,iconAspect:o,...s}=a;return e.jsx(n,{...s,children:e.jsx(h,{})})}},i={parameters:{...c,docs:{description:{story:"CmfIcon media — sized from `--ai-size` × scale × aspect (not Tabler stroke glyphs)."}}},render:a=>{const{iconScale:r,iconAspect:o,...s}=a;return e.jsx("div",{style:C({scale:r,aspect:o}),children:e.jsx(n,{...s,children:e.jsx(p,{alt:String(s["aria-label"]??"action")})})})}},l={parameters:{...c,docs:{description:{story:"Control tokens `--cmf-action-icon-icon-{scale|aspect|width|height}`."}}},render:()=>e.jsxs(g,{gap:"lg",align:"flex-start",children:[e.jsxs(g,{gap:"xs",children:[e.jsx(f,{size:"sm",fw:600,children:"scale 0.5 / 0.7 / 1"}),e.jsx(I,{gap:"md",children:["0.5","0.7","1"].map(a=>e.jsx("div",{style:y("action-icon",{scale:a,aspect:1}),children:e.jsx(n,{variant:"default","aria-label":`scale ${a}`,children:e.jsx(p,{alt:`scale ${a}`})})},a))})]}),e.jsxs(g,{gap:"xs",children:[e.jsx(f,{size:"sm",fw:600,children:"aspect 1 / 1.5 / 2 · scale 0.7"}),e.jsx(I,{gap:"md",children:["1","1.5","2"].map(a=>e.jsx("div",{style:y("action-icon",{scale:.7,aspect:a}),children:e.jsx(n,{variant:"outline","aria-label":`aspect ${a}`,children:e.jsx(p,{alt:`aspect ${a}`})})},a))})]})]})},d={parameters:{...c,docs:{...c.docs,description:{story:"Variant matrix for visual regression and token review."}}},render:()=>e.jsx(N,{items:x,columns:4,renderItem:a=>e.jsx(n,{variant:a,"aria-label":a,children:e.jsx(h,{})})})},m={parameters:{...O,controls:D.controls},render:function(){const[r,o]=$(),{iconScale:s,iconAspect:_,...u}=r;return e.jsx(b,{args:r,fields:k,onChange:o,children:e.jsx("div",{style:C({scale:s,aspect:_}),children:e.jsx(n,{...u,children:e.jsx(p,{alt:String(u["aria-label"]??"action")})})})})}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  parameters: elementDocsPreviewParameters,
  render: args => {
    const {
      iconScale: _s,
      iconAspect: _a,
      ...iconArgs
    } = args as ActionIconStoryArgs;
    return <ActionIcon {...iconArgs}>
        <DemoGlyph />
      </ActionIcon>;
  }
}`,...t.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      description: {
        story: 'CmfIcon media — sized from \`--ai-size\` × scale × aspect (not Tabler stroke glyphs).'
      }
    }
  },
  render: args => {
    const {
      iconScale,
      iconAspect,
      ...iconArgs
    } = args as ActionIconStoryArgs;
    return <div style={cmfIconCascadeStyle({
      scale: iconScale,
      aspect: iconAspect
    })}>
        <ActionIcon {...iconArgs}>
          <DemoCmfIcon alt={String(iconArgs['aria-label'] ?? 'action')} />
        </ActionIcon>
      </div>;
  }
}`,...i.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      description: {
        story: 'Control tokens \`--cmf-action-icon-icon-{scale|aspect|width|height}\`.'
      }
    }
  },
  render: () => <Stack gap="lg" align="flex-start">
      <Stack gap="xs">
        <Text size="sm" fw={600}>
          scale 0.5 / 0.7 / 1
        </Text>
        <Group gap="md">
          {(['0.5', '0.7', '1'] as const).map(scale => <div key={scale} style={cmfControlIconCascadeStyle('action-icon', {
          scale,
          aspect: 1
        })}>
              <ActionIcon variant="default" aria-label={\`scale \${scale}\`}>
                <DemoCmfIcon alt={\`scale \${scale}\`} />
              </ActionIcon>
            </div>)}
        </Group>
      </Stack>
      <Stack gap="xs">
        <Text size="sm" fw={600}>
          aspect 1 / 1.5 / 2 · scale 0.7
        </Text>
        <Group gap="md">
          {(['1', '1.5', '2'] as const).map(aspect => <div key={aspect} style={cmfControlIconCascadeStyle('action-icon', {
          scale: 0.7,
          aspect
        })}>
              <ActionIcon variant="outline" aria-label={\`aspect \${aspect}\`}>
                <DemoCmfIcon alt={\`aspect \${aspect}\`} />
              </ActionIcon>
            </div>)}
        </Group>
      </Stack>
    </Stack>
}`,...l.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      ...elementDocsPreviewParameters.docs,
      description: {
        story: 'Variant matrix for visual regression and token review.'
      }
    }
  },
  render: () => <VariantMatrix items={ACTION_ICON_STORY_VARIANTS} columns={4} renderItem={variant => <ActionIcon variant={variant} aria-label={variant}>
          <DemoGlyph />
        </ActionIcon>} />
}`,...d.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementPlaygroundParameters,
    controls: mantineDocsPlaygroundParameters.controls
  },
  render: function ActionIconPlayground() {
    const [args, updateArgs] = useArgs<ActionIconStoryArgs>();
    const {
      iconScale,
      iconAspect,
      ...iconArgs
    } = args;
    return <MantineDocsPlayground args={args} fields={ACTION_ICON_DOCS_PLAYGROUND_FIELDS} onChange={updateArgs}>
        <div style={cmfIconCascadeStyle({
        scale: iconScale,
        aspect: iconAspect
      })}>
          <ActionIcon {...iconArgs}>
            <DemoCmfIcon alt={String(iconArgs['aria-label'] ?? 'action')} />
          </ActionIcon>
        </div>
      </MantineDocsPlayground>;
  }
}`,...m.parameters?.docs?.source}}};const Q=["Default","WithCmfIcon","IconCascade","AllVariants","Playground"];export{d as AllVariants,t as Default,l as IconCascade,m as Playground,i as WithCmfIcon,Q as __namedExportsOrder,J as default};
