const e={docs:{story:{inline:!0}}},r={layout:"fullscreen",controls:{hideNoControlsWarning:!0},docs:{disable:!0}};export{r as a,e};
