import{j as e}from"./iframe-BrC--jVC.js";import{G as l}from"./CmfIcon-cXDjtVVC.js";import{S as t,T as a}from"./Stack-COJDyCZr.js";import{b as d}from"./cmfScopeOverrides-Dlj2pTxR.js";import{e as m}from"./elementStoryParameters-BoK8xJLb.js";import{H as p}from"./headerMenuControls-42o3i0-w.js";import{I as x,d as i,D as u}from"./registerBlocks-BNAojLQN.js";import"./preload-helper-gDVRIedU.js";import"./resolve-BqvS5tKn.js";import"./createReactComponent-hik4W6C4.js";const c="/uploads/jlogo.webp",g={iconOnlyLink:{key:"profile",name:"",url:"/profile",img:c,type:"link"},textButton:{key:"promo",name:"Promo",url:"/promo",type:"button"},iconAndText:{key:"casino",name:"Casino",url:"/",img:c,type:"link"},dropdownProfile:{key:"profile",name:"",url:"",img:c,type:"link",items:[{key:"deposit",name:"Deposit",url:"/deposit"},{key:"info",name:"Profile info",url:"/profile?tab=info"}]},brokenImgWithName:{key:"bonus",name:"Bonus",url:"/bonus",img:"/missing-menu-image.webp",type:"button"}};function s(n){return g[n]}const M={title:"Widgets/Header/Menu Items",tags:["autodocs"],parameters:{layout:"padded",...m,docs:{...m.docs,description:{component:"Default menu item renderers (`DefaultItemBlock`). Icon size via CMF cascade on `[data-widget=header]` / `--cmf-button-header-icon-*` / `--cmf-action-icon-header-icon-*`. Fixtures from `public/uploads`."}}}},o={render:()=>e.jsx(p,{children:e.jsxs(t,{gap:"xl",align:"flex-start",children:[e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Icon only · type link · transparent"}),e.jsx(l,{gap:"sm",children:e.jsx(x,{item:s("iconOnlyLink")})})]}),e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Text only · type button · default"}),e.jsx(i,{item:s("textButton")})]}),e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Icon + name · type link"}),e.jsx(i,{item:s("iconAndText")})]}),e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Dropdown · icon trigger + menu"}),e.jsx(u,{item:s("dropdownProfile")})]}),e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Broken image · fallback glyph when name is set"}),e.jsx(i,{item:s("brokenImgWithName")})]})]})})},r={parameters:{...m,docs:{description:{story:"Override `--cmf-button-icon-*` / `--cmf-action-icon-icon-*` around menu items (same cascade as widget tokens)."}}},render:()=>e.jsx(p,{children:e.jsxs(t,{gap:"xl",align:"flex-start",children:[e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"ActionIcon · scale 0.5 / 0.7 / 1"}),e.jsx(l,{gap:"md",children:["0.5","0.7","1"].map(n=>e.jsx("div",{style:d("action-icon","header",{scale:n,aspect:1}),children:e.jsx(x,{item:s("iconOnlyLink")})},n))})]}),e.jsxs(t,{gap:"xs",align:"flex-start",children:[e.jsx(a,{size:"sm",fw:600,children:"Button · aspect 1 / 1.5 / 2 (sidebar-like)"}),e.jsx(l,{gap:"md",children:["1","1.5","2"].map(n=>e.jsx("div",{style:d("button","header",{scale:.7,aspect:n}),children:e.jsx(i,{item:s("iconAndText")})},n))})]})]})})};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => <HeaderMenuControlsShell>
      <Stack gap="xl" align="flex-start">
        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Icon only · type link · transparent
          </Text>
          <Group gap="sm">
            <ItemActionIcon item={getHeaderMenuItemFixture('iconOnlyLink')} />
          </Group>
        </Stack>

        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Text only · type button · default
          </Text>
          <ItemButton item={getHeaderMenuItemFixture('textButton')} />
        </Stack>

        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Icon + name · type link
          </Text>
          <ItemButton item={getHeaderMenuItemFixture('iconAndText')} />
        </Stack>

        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Dropdown · icon trigger + menu
          </Text>
          <Dropdown item={getHeaderMenuItemFixture('dropdownProfile')} />
        </Stack>

        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Broken image · fallback glyph when name is set
          </Text>
          <ItemButton item={getHeaderMenuItemFixture('brokenImgWithName')} />
        </Stack>
      </Stack>
    </HeaderMenuControlsShell>
}`,...o.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  parameters: {
    ...elementDocsPreviewParameters,
    docs: {
      description: {
        story: 'Override \`--cmf-button-icon-*\` / \`--cmf-action-icon-icon-*\` around menu items (same cascade as widget tokens).'
      }
    }
  },
  render: () => <HeaderMenuControlsShell>
      <Stack gap="xl" align="flex-start">
        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            ActionIcon · scale 0.5 / 0.7 / 1
          </Text>
          <Group gap="md">
            {(['0.5', '0.7', '1'] as const).map(scale => <div key={scale} style={cmfComponentIconCascadeStyle('action-icon', 'header', {
            scale,
            aspect: 1
          })}>
                <ItemActionIcon item={getHeaderMenuItemFixture('iconOnlyLink')} />
              </div>)}
          </Group>
        </Stack>

        <Stack gap="xs" align="flex-start">
          <Text size="sm" fw={600}>
            Button · aspect 1 / 1.5 / 2 (sidebar-like)
          </Text>
          <Group gap="md">
            {(['1', '1.5', '2'] as const).map(aspect => <div key={aspect} style={cmfComponentIconCascadeStyle('button', 'header', {
            scale: 0.7,
            aspect
          })}>
                <ItemButton item={getHeaderMenuItemFixture('iconAndText')} />
              </div>)}
          </Group>
        </Stack>
      </Stack>
    </HeaderMenuControlsShell>
}`,...r.parameters?.docs?.source}}};const H=["Overview","IconCascade"];export{r as IconCascade,o as Overview,H as __namedExportsOrder,M as default};
