import{j as a}from"./iframe-BrC--jVC.js";import{b as n}from"./registerBlocks-BNAojLQN.js";import{r as i}from"./resolve-BqvS5tKn.js";import{R as c}from"./Root-A1ukeKc3.js";import"./preload-helper-gDVRIedU.js";import"./CmfIcon-cXDjtVVC.js";import"./createReactComponent-hik4W6C4.js";function m(){return{menu:n(),config:i()}}function u(e={}){const{menu:s,config:t}=m();return a.jsx(c,{menu:s,config:{...t,...e.config},className:e.className})}const x={title:"Widgets/Header/AppHeader",tags:["autodocs"],parameters:{layout:"fullscreen",docs:{description:{component:"Full header shell from API/fixture menu. Toolbar **Header session** toggles authenticated vs guest mock menu. Special blocks and menu item primitives live in sibling stories."}}},render:e=>u(e),args:{}},r={},o={args:{config:{layout:"container-fluid"}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:"{}",...r.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    config: {
      layout: 'container-fluid'
    }
  }
}`,...o.parameters?.docs?.source}}};const v=["Default","ContainerFluid"];export{o as ContainerFluid,r as Default,v as __namedExportsOrder,x as default};
