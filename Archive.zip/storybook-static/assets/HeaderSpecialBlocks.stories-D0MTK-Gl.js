import{j as e}from"./iframe-BrC--jVC.js";import{G as c}from"./CmfIcon-cXDjtVVC.js";import{S as t,T as r}from"./Stack-COJDyCZr.js";import{e as l}from"./elementStoryParameters-BoK8xJLb.js";import{g as m,H as i}from"./headerMenuControls-42o3i0-w.js";import{S as n,W as d,C as p}from"./registerBlocks-BNAojLQN.js";import"./preload-helper-gDVRIedU.js";import"./resolve-BqvS5tKn.js";import"./createReactComponent-hik4W6C4.js";const I={title:"Widgets/Header/Special Blocks",tags:["autodocs"],parameters:{layout:"padded",...l,docs:{...l.docs,description:{component:"Registry blocks with dedicated UI (`search`, `wallet`, `color_scheme`, …). No menu `type` / name+img rules."}}}},s={render:()=>{const{searchItem:a,walletItem:o}=m();return e.jsx(i,{children:e.jsxs(c,{gap:"lg",align:"flex-start",children:[e.jsxs(t,{gap:"xs",children:[e.jsx(r,{size:"sm",fw:600,children:"Search"}),a!==void 0?e.jsx(n,{item:a}):null]}),e.jsxs(t,{gap:"xs",children:[e.jsx(r,{size:"sm",fw:600,children:"Wallet"}),o!==void 0?e.jsx(d,{item:o}):null]}),e.jsxs(t,{gap:"xs",children:[e.jsx(r,{size:"sm",fw:600,children:"Color scheme"}),e.jsx(p,{item:{key:"color_scheme",url:"",name:""}})]})]})})}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => {
    const {
      searchItem,
      walletItem
    } = getHeaderMenuControlItems();
    return <HeaderMenuControlsShell>
        <Group gap="lg" align="flex-start">
          <Stack gap="xs">
            <Text size="sm" fw={600}>
              Search
            </Text>
            {searchItem !== undefined ? <SearchBlock item={searchItem} /> : null}
          </Stack>
          <Stack gap="xs">
            <Text size="sm" fw={600}>
              Wallet
            </Text>
            {walletItem !== undefined ? <WalletBlock item={walletItem} /> : null}
          </Stack>
          <Stack gap="xs">
            <Text size="sm" fw={600}>
              Color scheme
            </Text>
            <ColorSchemeBlock item={{
            key: 'color_scheme',
            url: '',
            name: ''
          }} />
          </Stack>
        </Group>
      </HeaderMenuControlsShell>;
  }
}`,...s.parameters?.docs?.source}}};const C=["Blocks"];export{s as Blocks,C as __namedExportsOrder,I as default};
