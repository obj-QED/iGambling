import{r as u,j as s,L as y,K as M}from"./iframe-BrC--jVC.js";import{m as x,i as N,j as _,k as R,l as B,n as A,a as L,H as K}from"./registerBlocks-BNAojLQN.js";import{G as c}from"./CmfIcon-cXDjtVVC.js";function E(e){return e==="prepend"?{kind:"new-section",header:"start"}:e==="append"?{kind:"new-section",header:"end"}:"section"in e&&"at"in e?{kind:"in-section",sectionKey:e.section,at:e.at}:"sectionKey"in e&&"position"in e?{kind:"in-section",sectionKey:e.sectionKey,at:e.position}:"beforeSection"in e?{kind:"new-section",beforeSection:e.beforeSection}:"afterSection"in e?{kind:"new-section",afterSection:e.afterSection}:"header"in e?{kind:"new-section",header:e.header}:null}function d(e,n,r){return n<0?e:[...e.slice(0,n),r,...e.slice(n)]}function z(e,n,r){if(r==="start")return[...n,...e];if(r==="end")return[...e,...n];const a=Math.max(0,Math.min(r,e.length));return[...e.slice(0,a),...n,...e.slice(a)]}function D(e,n,r,a){const i=e.sections.findIndex(t=>t.key===n);return i===-1?e:{sections:e.sections.map((t,o)=>o!==i?t:{...t,items:z(t.items,a,r)})}}function V(e,n){const r=n.items.map(t=>x(t));if(r.length===0)return e;const a=E(n.placement);if(a===null)return e;if(a.kind==="in-section")return D(e,a.sectionKey,a.at,r);const i={key:n.key,items:r};if("header"in a)return a.header==="start"?{sections:[i,...e.sections]}:{sections:[...e.sections,i]};if("beforeSection"in a){const t=e.sections.findIndex(o=>o.key===a.beforeSection);return t===-1?e:{sections:d(e.sections,t,i)}}const l=e.sections.findIndex(t=>t.key===a.afterSection);return l===-1?e:{sections:d(e.sections,l+1,i)}}function F(e,n){return n===void 0||n.length===0?e:n.reduce((r,a)=>V(r,a),e)}function G(e){const[n,r]=u.useState(N);return u.useLayoutEffect(()=>{r(_(e))},[e]),n}const Y="FbD3vY6Z",$={root:Y};function g({children:e}){return s.jsx(y,{className:$.root,fluid:!0,children:e})}const p=u.memo(g);p.displayName="ContainerFluidLayout";g.__docgenInfo={description:"",methods:[],displayName:"ContainerFluidLayoutComponent",props:{children:{required:!0,tsType:{name:"ReactNode"},description:""}}};const P="j8nGNyb8",U={root:P};function f({children:e}){return s.jsx(y,{className:U.root,size:"responsive",children:e})}const k=u.memo(f);k.displayName="ContainerLayout";f.__docgenInfo={description:"",methods:[],displayName:"ContainerLayoutComponent",props:{children:{required:!0,tsType:{name:"ReactNode"},description:""}}};const Q={container:k,"container-fluid":p};function v({item:e}){const n=R(e);return s.jsx(n,{item:e})}const q=u.memo(v);q.displayName="Block";v.__docgenInfo={description:"",methods:[],displayName:"BlockComponent",props:{item:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  key?: string;
  url?: string;
  name?: string;
  img?: string;
  imgShape?: string;
  imgRadius?: string;
  type?: string;
  badge?: string | number;
  subtitle?: string;
  items?: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!1}},{key:"url",value:{name:"string",required:!1}},{key:"name",value:{name:"string",required:!1}},{key:"img",value:{name:"string",required:!1}},{key:"imgShape",value:{name:"string",required:!1}},{key:"imgRadius",value:{name:"string",required:!1}},{key:"type",value:{name:"string",required:!1}},{key:"badge",value:{name:"union",raw:"string | number",elements:[{name:"string"},{name:"number"}],required:!1}},{key:"subtitle",value:{name:"string",required:!1}},{key:"items",value:{name:"Array",elements:[{name:"HeaderMenuItem"}],raw:"HeaderMenuItem[]",required:!1}}]}},description:""}}};const Z="PQIhSDQU",O={root:Z};function b({section:e}){const n=B(e.items);return n.length===0?null:s.jsx(c,{className:O.root,gap:"sm",wrap:"nowrap","data-section-key":e.key,children:n.map(r=>s.jsx(q,{item:r},r.key))})}const w=u.memo(b);w.displayName="Section";b.__docgenInfo={description:"",methods:[],displayName:"SectionComponent",props:{section:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  key: string;
  items: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!0}},{key:"items",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key?: string;
  url?: string;
  name?: string;
  img?: string;
  imgShape?: string;
  imgRadius?: string;
  type?: string;
  badge?: string | number;
  subtitle?: string;
  items?: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!1}},{key:"url",value:{name:"string",required:!1}},{key:"name",value:{name:"string",required:!1}},{key:"img",value:{name:"string",required:!1}},{key:"imgShape",value:{name:"string",required:!1}},{key:"imgRadius",value:{name:"string",required:!1}},{key:"type",value:{name:"string",required:!1}},{key:"badge",value:{name:"union",raw:"string | number",elements:[{name:"string"},{name:"number"}],required:!1}},{key:"subtitle",value:{name:"string",required:!1}},{key:"items",value:{name:"Array",elements:[{name:"HeaderMenuItem"}],raw:"HeaderMenuItem[]",required:!1}}]}}],raw:"HeaderMenuItem[]",required:!0}}]}},description:""}}};const W="Gb5Npfmf",J={sections:W};function H({menu:e,config:n}){const r=Q[n.layout],a=e.sections.filter(i=>i.items.length>0);return a.length===0?null:s.jsx(r,{children:s.jsx(c,{className:J.sections,justify:"space-between",wrap:"nowrap",gap:"md",children:a.map(i=>s.jsx(w,{section:i},i.key))})})}const m=u.memo(H);m.displayName="Shell";H.__docgenInfo={description:"",methods:[],displayName:"ShellComponent"};function S({menu:e,config:n}){return s.jsx(m,{menu:e,config:n})}const h=u.memo(S);h.displayName="ClassicTypeStrategy";S.__docgenInfo={description:"",methods:[],displayName:"ClassicTypeStrategyComponent",props:{menu:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  sections: HeaderSection[];
}`,signature:{properties:[{key:"sections",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key: string;
  items: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!0}},{key:"items",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key?: string;
  url?: string;
  name?: string;
  img?: string;
  imgShape?: string;
  imgRadius?: string;
  type?: string;
  badge?: string | number;
  subtitle?: string;
  items?: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!1}},{key:"url",value:{name:"string",required:!1}},{key:"name",value:{name:"string",required:!1}},{key:"img",value:{name:"string",required:!1}},{key:"imgShape",value:{name:"string",required:!1}},{key:"imgRadius",value:{name:"string",required:!1}},{key:"type",value:{name:"string",required:!1}},{key:"badge",value:{name:"union",raw:"string | number",elements:[{name:"string"},{name:"number"}],required:!1}},{key:"subtitle",value:{name:"string",required:!1}},{key:"items",value:{name:"Array",elements:[{name:"HeaderMenuItem"}],raw:"HeaderMenuItem[]",required:!1}}]}}],raw:"HeaderMenuItem[]",required:!0}}]}}],raw:"HeaderSection[]",required:!0}}]}},description:""},config:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  layout: HeaderLayoutKey;
  type: HeaderTypeKey;
  blockVariants: HeaderBlockVariants;
  customBlocks?: HeaderCustomBlockConfig[];
}`,signature:{properties:[{key:"layout",value:{name:"HeaderLayoutKey",required:!0}},{key:"type",value:{name:"HeaderTypeKey",required:!0}},{key:"blockVariants",value:{name:"signature",type:"object",raw:`{
  search?: 'input' | 'icon' | 'modal';
  wallet?: 'compact' | 'full' | 'drawer';
  notification?: 'icon';
  logo?: 'default';
  bonus_box?: 'default';
}`,signature:{properties:[{key:"search",value:{name:"union",raw:"'input' | 'icon' | 'modal'",elements:[{name:"literal",value:"'input'"},{name:"literal",value:"'icon'"},{name:"literal",value:"'modal'"}],required:!1}},{key:"wallet",value:{name:"union",raw:"'compact' | 'full' | 'drawer'",elements:[{name:"literal",value:"'compact'"},{name:"literal",value:"'full'"},{name:"literal",value:"'drawer'"}],required:!1}},{key:"notification",value:{name:"literal",value:"'icon'",required:!1}},{key:"logo",value:{name:"literal",value:"'default'",required:!1}},{key:"bonus_box",value:{name:"literal",value:"'default'",required:!1}}]},required:!0}},{key:"customBlocks",value:{name:"Array",elements:[{name:"HeaderCustomBlockConfig"}],raw:"HeaderCustomBlockConfig[]",required:!1}}]}},description:""},className:{required:!1,tsType:{name:"string"},description:""}}};function C({menu:e,config:n}){return s.jsx(m,{menu:e,config:n})}const I=u.memo(C);I.displayName="DefaultTypeStrategy";C.__docgenInfo={description:"",methods:[],displayName:"DefaultTypeStrategyComponent",props:{menu:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  sections: HeaderSection[];
}`,signature:{properties:[{key:"sections",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key: string;
  items: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!0}},{key:"items",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key?: string;
  url?: string;
  name?: string;
  img?: string;
  imgShape?: string;
  imgRadius?: string;
  type?: string;
  badge?: string | number;
  subtitle?: string;
  items?: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!1}},{key:"url",value:{name:"string",required:!1}},{key:"name",value:{name:"string",required:!1}},{key:"img",value:{name:"string",required:!1}},{key:"imgShape",value:{name:"string",required:!1}},{key:"imgRadius",value:{name:"string",required:!1}},{key:"type",value:{name:"string",required:!1}},{key:"badge",value:{name:"union",raw:"string | number",elements:[{name:"string"},{name:"number"}],required:!1}},{key:"subtitle",value:{name:"string",required:!1}},{key:"items",value:{name:"Array",elements:[{name:"HeaderMenuItem"}],raw:"HeaderMenuItem[]",required:!1}}]}}],raw:"HeaderMenuItem[]",required:!0}}]}}],raw:"HeaderSection[]",required:!0}}]}},description:""},config:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  layout: HeaderLayoutKey;
  type: HeaderTypeKey;
  blockVariants: HeaderBlockVariants;
  customBlocks?: HeaderCustomBlockConfig[];
}`,signature:{properties:[{key:"layout",value:{name:"HeaderLayoutKey",required:!0}},{key:"type",value:{name:"HeaderTypeKey",required:!0}},{key:"blockVariants",value:{name:"signature",type:"object",raw:`{
  search?: 'input' | 'icon' | 'modal';
  wallet?: 'compact' | 'full' | 'drawer';
  notification?: 'icon';
  logo?: 'default';
  bonus_box?: 'default';
}`,signature:{properties:[{key:"search",value:{name:"union",raw:"'input' | 'icon' | 'modal'",elements:[{name:"literal",value:"'input'"},{name:"literal",value:"'icon'"},{name:"literal",value:"'modal'"}],required:!1}},{key:"wallet",value:{name:"union",raw:"'compact' | 'full' | 'drawer'",elements:[{name:"literal",value:"'compact'"},{name:"literal",value:"'full'"},{name:"literal",value:"'drawer'"}],required:!1}},{key:"notification",value:{name:"literal",value:"'icon'",required:!1}},{key:"logo",value:{name:"literal",value:"'default'",required:!1}},{key:"bonus_box",value:{name:"literal",value:"'default'",required:!1}}]},required:!0}},{key:"customBlocks",value:{name:"Array",elements:[{name:"HeaderCustomBlockConfig"}],raw:"HeaderCustomBlockConfig[]",required:!1}}]}},description:""},className:{required:!1,tsType:{name:"string"},description:""}}};const X={default:I,custom:h},ee="DtsYyPiW",ne={root:ee};function j({menu:e,config:n,className:r}){const[a,i]=u.useState(null),l=G(a),t=X[n.type],o=u.useMemo(()=>{const T=F(e,n.customBlocks);return A(T)},[e,n.customBlocks]);return t===void 0||o.sections.length===0?null:s.jsx(L,{config:n,children:s.jsx(K.Provider,{value:l,children:s.jsx("header",{ref:i,className:M(ne.root,r),"data-widget":"header","data-cmf-component":"header","data-layout":n.layout,"data-type":n.type,children:s.jsx(t,{menu:o,config:n})})})})}const re=u.memo(j);re.displayName="Root";j.__docgenInfo={description:"",methods:[],displayName:"RootComponent",props:{menu:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  sections: HeaderSection[];
}`,signature:{properties:[{key:"sections",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key: string;
  items: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!0}},{key:"items",value:{name:"Array",elements:[{name:"signature",type:"object",raw:`{
  key?: string;
  url?: string;
  name?: string;
  img?: string;
  imgShape?: string;
  imgRadius?: string;
  type?: string;
  badge?: string | number;
  subtitle?: string;
  items?: HeaderMenuItem[];
}`,signature:{properties:[{key:"key",value:{name:"string",required:!1}},{key:"url",value:{name:"string",required:!1}},{key:"name",value:{name:"string",required:!1}},{key:"img",value:{name:"string",required:!1}},{key:"imgShape",value:{name:"string",required:!1}},{key:"imgRadius",value:{name:"string",required:!1}},{key:"type",value:{name:"string",required:!1}},{key:"badge",value:{name:"union",raw:"string | number",elements:[{name:"string"},{name:"number"}],required:!1}},{key:"subtitle",value:{name:"string",required:!1}},{key:"items",value:{name:"Array",elements:[{name:"HeaderMenuItem"}],raw:"HeaderMenuItem[]",required:!1}}]}}],raw:"HeaderMenuItem[]",required:!0}}]}}],raw:"HeaderSection[]",required:!0}}]}},description:""},config:{required:!0,tsType:{name:"signature",type:"object",raw:`{
  layout: HeaderLayoutKey;
  type: HeaderTypeKey;
  blockVariants: HeaderBlockVariants;
  customBlocks?: HeaderCustomBlockConfig[];
}`,signature:{properties:[{key:"layout",value:{name:"HeaderLayoutKey",required:!0}},{key:"type",value:{name:"HeaderTypeKey",required:!0}},{key:"blockVariants",value:{name:"signature",type:"object",raw:`{
  search?: 'input' | 'icon' | 'modal';
  wallet?: 'compact' | 'full' | 'drawer';
  notification?: 'icon';
  logo?: 'default';
  bonus_box?: 'default';
}`,signature:{properties:[{key:"search",value:{name:"union",raw:"'input' | 'icon' | 'modal'",elements:[{name:"literal",value:"'input'"},{name:"literal",value:"'icon'"},{name:"literal",value:"'modal'"}],required:!1}},{key:"wallet",value:{name:"union",raw:"'compact' | 'full' | 'drawer'",elements:[{name:"literal",value:"'compact'"},{name:"literal",value:"'full'"},{name:"literal",value:"'drawer'"}],required:!1}},{key:"notification",value:{name:"literal",value:"'icon'",required:!1}},{key:"logo",value:{name:"literal",value:"'default'",required:!1}},{key:"bonus_box",value:{name:"literal",value:"'default'",required:!1}}]},required:!0}},{key:"customBlocks",value:{name:"Array",elements:[{name:"HeaderCustomBlockConfig"}],raw:"HeaderCustomBlockConfig[]",required:!1}}]}},description:""},className:{required:!1,tsType:{name:"string"},description:""}}};export{re as R,V as m};
