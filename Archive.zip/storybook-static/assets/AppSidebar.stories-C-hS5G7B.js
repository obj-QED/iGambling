import{j as a}from"./iframe-BrC--jVC.js";import{h as n}from"./registerBlocks-BNAojLQN.js";import{r as c,R as d}from"./Root-twd1WL4G.js";import"./preload-helper-gDVRIedU.js";import"./CmfIcon-cXDjtVVC.js";import"./createReactComponent-hik4W6C4.js";import"./to-int-CdRLc0g2.js";import"./Root-A1ukeKc3.js";function m(){return{menu:n(),config:c()}}function p(e={}){const{menu:t,config:i}=m();return a.jsx("div",{style:{display:"flex",minHeight:"100vh",background:"var(--color-bg-body, #0f172a)"},children:a.jsx(d,{menu:t,config:{...i,...e.config},className:e.className})})}const x={title:"Widgets/Sidebar/AppSidebar",tags:["autodocs"],parameters:{layout:"fullscreen",docs:{description:{component:"Left aside shell with scrollable menu. Toolbar **Aside mock menu** and **Aside width** map to `window.__SETTINGS__.aside`. Icon media: `--cmf-button-sidebar-icon-{scale|aspect|width|height}` in `sidebar/tokens.scss`."}}},render:e=>p(e),args:{}},r={},o={args:{config:{width:320}}},s={args:{config:{width:480}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:"{}",...r.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    config: {
      width: 320
    }
  }
}`,...o.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    config: {
      width: 480
    }
  }
}`,...s.parameters?.docs?.source}}};const y=["Default","Narrow","Wide"];export{r as Default,o as Narrow,s as Wide,y as __namedExportsOrder,x as default};
