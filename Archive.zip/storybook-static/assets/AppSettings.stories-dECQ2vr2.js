import{l as w,u as h,m as j,j as e,n as P,o as A,p as N,q as d,T as p,s as O,S as R}from"./iframe-BrC--jVC.js";import{S as t,T as a}from"./Stack-COJDyCZr.js";import{b as C,h as E,g as G}from"./registerBlocks-BNAojLQN.js";import{r as H}from"./resolve-BqvS5tKn.js";import{R as z}from"./Root-A1ukeKc3.js";import{r as I,R as J}from"./Root-twd1WL4G.js";import"./preload-helper-gDVRIedU.js";import"./CmfIcon-cXDjtVVC.js";import"./createReactComponent-hik4W6C4.js";import"./to-int-CdRLc0g2.js";var g={root:"m_b183c0a2"};const S=A((r,{color:s})=>({root:{"--code-bg":s?N(s,r):void 0}})),o=w(r=>{const s=h("Code",null,r),{classNames:c,className:u,style:b,styles:x,unstyled:T,vars:y,color:K,block:m,mod:f,attributes:_,...v}=s,k=j({name:"Code",props:s,classes:g,className:u,style:b,classNames:c,styles:x,unstyled:T,attributes:_,vars:y,varsResolver:S});return e.jsx(P,{component:m?"pre":"code",mod:[{block:m},f],...k("root"),...v,dir:"ltr"})});o.classes=g;o.varsResolver=S;o.displayName="@mantine/core/Code";function B(){const r=G();return e.jsx(o,{block:!0,style:{whiteSpace:"pre-wrap"},children:JSON.stringify(r,null,2)})}function D(){const r=C(),s=H();return e.jsx(z,{menu:r,config:s})}function F(){const r=E(),s=I();return e.jsx("div",{style:{display:"flex",minHeight:480,background:"var(--color-bg-body)"},children:e.jsx(J,{menu:r,config:s})})}const Z={title:"Settings/App",tags:["autodocs"],parameters:{layout:"padded",docs:{description:{component:"Runtime visual config from `window.__SETTINGS__`. Toolbar controls header, aside, and color scheme — values apply before each story. Theme bridge: `@/assets/theme` (`mantine/theme/mantineTheme.ts`)."}}}},n={render:(r,s)=>{d(s.globals);const c=O(s.globals);return e.jsxs(t,{gap:"md",children:[e.jsx(p,{order:3,children:"App settings (Storybook)"}),e.jsx(a,{c:"dimmed",size:"sm",children:"Toolbar globals map to `window.__SETTINGS__`. Production defaults live in `src/assets/settings/index.js`; Storybook uses `src/storybook/settings/`."}),e.jsxs(t,{gap:"xs",children:[e.jsx(a,{fw:600,size:"sm",children:"Active toolbar values"}),e.jsx(o,{block:!0,children:JSON.stringify(c,null,2)})]}),e.jsxs(t,{gap:"xs",children:[e.jsx(a,{fw:600,size:"sm",children:"Resolved `window.__SETTINGS__`"}),e.jsx(B,{})]}),e.jsxs(t,{gap:"xs",children:[e.jsx(a,{fw:600,size:"sm",children:"Production defaults (reference)"}),e.jsx(o,{block:!0,children:JSON.stringify(R,null,2)})]})]})}},i={parameters:{layout:"fullscreen"},render:(r,s)=>(d(s.globals),e.jsxs(t,{gap:"md",p:"md",children:[e.jsx(p,{order:4,children:"Header with current settings"}),e.jsx(D,{})]}))},l={parameters:{layout:"padded"},render:(r,s)=>(d(s.globals),e.jsxs(t,{gap:"md",children:[e.jsx(p,{order:4,children:"Sidebar with current settings"}),e.jsx(F,{})]}))};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: (_args, context) => {
    applyStorybookAppSettings(context.globals);
    const globals = readStorybookAppSettingsGlobals(context.globals);
    return <Stack gap="md">
        <Title order={3}>App settings (Storybook)</Title>
        <Text c="dimmed" size="sm">
          Toolbar globals map to \`window.__SETTINGS__\`. Production defaults live in
          \`src/assets/settings/index.js\`; Storybook uses \`src/storybook/settings/\`.
        </Text>
        <Stack gap="xs">
          <Text fw={600} size="sm">
            Active toolbar values
          </Text>
          <Code block>{JSON.stringify(globals, null, 2)}</Code>
        </Stack>
        <Stack gap="xs">
          <Text fw={600} size="sm">
            Resolved \`window.__SETTINGS__\`
          </Text>
          <SettingsJsonPreview />
        </Stack>
        <Stack gap="xs">
          <Text fw={600} size="sm">
            Production defaults (reference)
          </Text>
          <Code block>{JSON.stringify(STORYBOOK_APP_SETTINGS_DEFAULTS, null, 2)}</Code>
        </Stack>
      </Stack>;
  }
}`,...n.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  parameters: {
    layout: 'fullscreen'
  },
  render: (_args, context) => {
    applyStorybookAppSettings(context.globals);
    return <Stack gap="md" p="md">
        <Title order={4}>Header with current settings</Title>
        <HeaderSettingsPreview />
      </Stack>;
  }
}`,...i.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  parameters: {
    layout: 'padded'
  },
  render: (_args, context) => {
    applyStorybookAppSettings(context.globals);
    return <Stack gap="md">
        <Title order={4}>Sidebar with current settings</Title>
        <SidebarSettingsPreview />
      </Stack>;
  }
}`,...l.parameters?.docs?.source}}};const ee=["Overview","HeaderPreview","SidebarPreview"];export{i as HeaderPreview,n as Overview,l as SidebarPreview,ee as __namedExportsOrder,Z as default};
