export { InfoPageLayout } from './InfoPageLayout';
