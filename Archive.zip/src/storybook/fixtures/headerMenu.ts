import type { MenuItemDto } from '@/shared/types/menu';
import type { HeaderMenuItem, HeaderMenuModel } from '@/widgets/header/types';

import { parseMenuItemDto } from '@/shared/lib/menu';
import { mapRoot } from '@/widgets/header/lib/mapMenu';
import { MENU_HEADER_TOP_AUTHENTICATED_MOCK } from '@/widgets/header/mocks/menuHeaderTop/menuHeaderTop.authenticated.mock';

function parseMockItems(): MenuItemDto[] {
  const items: MenuItemDto[] = [];

  for (const entry of MENU_HEADER_TOP_AUTHENTICATED_MOCK.menu) {
    const parsed = parseMenuItemDto(entry);
    if (parsed !== null) items.push(parsed);
  }

  return items;
}

export function createHeaderMenuFixture(): HeaderMenuModel {
  return mapRoot({
    key: 'menuHeaderTop',
    name: '',
    url: '',
    items: parseMockItems(),
  });
}

/** Empty menu when `header.mockMenu` is off (matches app without init/mock). */
export function createEmptyHeaderMenuFixture(): HeaderMenuModel {
  return mapRoot({
    key: 'menuHeaderTop',
    name: '',
    url: '',
    items: [],
  });
}

export function findHeaderMenuItem(menu: HeaderMenuModel, key: string): HeaderMenuItem | undefined {
  for (const section of menu.sections) {
    const found = findInItems(section.items, key);
    if (found !== undefined) return found;
  }

  return undefined;
}

function findInItems(items: HeaderMenuItem[], key: string): HeaderMenuItem | undefined {
  for (const item of items) {
    if (item.key === key) return item;
    const nested = item.items;
    if (nested !== undefined) {
      const found = findInItems(nested, key);
      if (found !== undefined) return found;
    }
  }

  return undefined;
}
